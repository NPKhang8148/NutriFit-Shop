// import { createApp } from 'vue';
// import App from './App.vue';
// import router from './router';
// import { createPinia } from 'pinia';
// import vuetify from './plugins/vuetify'

// import 'bootstrap/dist/css/bootstrap.min.css';
// import 'bootstrap/dist/js/bootstrap.bundle.min.js';
// import './style.css';

// const app = createApp(App)
// const pinia = createPinia();
// app.use(router)
// app.use(pinia);
// app.mount('#app')

import { createApp } from "vue";
import App from "./App.vue";
import router from "./router";
import { createPinia } from "pinia";
import vuetify from "./plugins/vuetify";
// Import Element Plus + CSS
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'

import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min.js";
import "./style.css";

const app = createApp(App);

app.use(router);
app.use(createPinia()); 
app.use(vuetify);
app.use(ElementPlus)


app.mount("#app");
