<template>
  <div class="container py-4">
    <h2 class="text-center fw-bold pb-3" style="color: #e04338">
      CHI TIẾT ĐƠN HÀNG
    </h2>

    <div v-if="order">
      <!-- Thông tin đơn hàng -->
      <div class="row align-items-start mb-3">
        <div class="col-md-8 text-start">
          <p><strong>Trạng thái:</strong> {{ order.status }}</p>
          <p>
            <strong>Ngày đặt:</strong>
            {{ new Date(order.createdAt).toLocaleString() }}
          </p>
          <p><strong>Địa chỉ giao hàng:</strong> {{ order.shippingAddress }}</p>
        </div>

        <div class="col-md-4 text-end">
          <button
            v-if="order.status === 'Đã giao hàng'"
            @click="confirmReceived"
            class="my-btn"
          >
            Đã nhận hàng
          </button>
        </div>
      </div>

      <!-- Danh sách sản phẩm -->
      <h4 class="mt-4">Sản phẩm:</h4>
      <ul class="list-group">
        <li
          class="list-group-item"
          v-for="(item, index) in order.orderItems"
          :key="index"
        >
          <div class="d-flex justify-content-between align-items-center">
            <div>
              <div>
                <router-link
                  :to="`/product/${item.product._id}`"
                  class="text-decoration-none text-dark fw-bold"
                >
                  {{ item?.product?.name || "Không xác định" }}
                </router-link>
                &nbsp;- Số lượng: {{ item.quantity }} &nbsp;- Giá:
                {{ item.price.toLocaleString() }} đ
              </div>

              <div
                v-if="
                  item.customOptions &&
                  Object.keys(item.customOptions).length > 0
                "
                class="mt-1"
              >
                <small class="text-muted"
                  ><strong style="color: #e04338"
                    >Tùy chọn thiết kế:</strong
                  ></small
                >
                <ul class="mb-0 ps-3">
                  <li
                    v-for="(value, key) in item.customOptions"
                    :key="key"
                    style="font-style: italic"
                  >
                    {{ key }}:
                    {{
                      findLabelForChoice(
                        key,
                        value,
                        item.product?.options || []
                      )
                    }}
                  </li>
                </ul>
              </div>
            </div>

            <div class="fw-bold text-end" style="min-width: 140px">
              Tổng: {{ (item.quantity * item.price).toLocaleString() }} đ
            </div>
          </div>

          <!-- Nút đánh giá (chỉ khi Hoàn thành) -->
          <div class="mt-2 text-end" v-if="order.status === 'Hoàn thành'">
            <button
              class="btn btn-outline-secondary btn-sm"
              @click="openReviewModal(item.product._id)"
            >
              Đánh giá sản phẩm
            </button>
          </div>
        </li>
      </ul>

      <div class="text-end mt-4">
        <h5 style="color: #e04338">
          Tổng tiền: {{ order.totalPrice.toLocaleString() }} đ
        </h5>
      </div>

      <!-- Modal đánh giá -->
      <ReviewModal
        v-if="showModal"
        :productId="selectedProductId"
        :orderId="order._id"
        @close="showModal = false"
      />
    </div>

    <div v-else>
      <p>Đang tải...</p>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import { useRoute, useRouter } from "vue-router";
import axios from "axios";
import { useAuthStore } from "@/stores/auth";
import ReviewModal from "../components/ReviewModal.vue";

const route = useRoute();
const router = useRouter();
const auth = useAuthStore();

const order = ref(null);
const showModal = ref(false);
const selectedProductId = ref(null);

const fetchOrder = async () => {
  try {
    const res = await axios.get(
      `http://localhost:5000/api/users/orders/${route.params.id}`,
      {
        headers: {
          Authorization: `Bearer ${auth.token}`,
        },
      }
    );
    order.value = res.data;
  } catch (err) {
    console.error(err);
    alert("Không thể tải đơn hàng.");
    router.push("/orders");
  }
};

const openReviewModal = (productId) => {
  selectedProductId.value = productId;
  showModal.value = true;
};

const findLabelForChoice = (key, value, options = []) => {
  const opt = options.find((o) => o.name === key);
  const choice = opt?.choices?.find((c) => c.value === value);
  return choice?.label || value;
};

const confirmReceived = async () => {
  const confirm = window.confirm("Bạn chắc chắn đã nhận được hàng?");
  if (!confirm) return;

  try {
    await axios.post(
      `http://localhost:5000/api/users/orders/${order.value._id}/complete`,
      {},
      {
        headers: { Authorization: `Bearer ${auth.token}` },
      }
    );
    alert("Cảm ơn bạn đã xác nhận!");
    fetchOrder();
  } catch (err) {
    alert("Lỗi xác nhận đơn hàng");
    console.error(err);
  }
};

onMounted(() => {
  if (!auth.user) {
    router.push("/login");
  } else {
    fetchOrder();
  }
});
</script>
