<template>
  <div>
    <Navbar />

    <div class="container">
      <div class="container py-4">
        <h2 class="fw-bold">ĐẶT HÀNG</h2>

        <div v-if="cart && cart.items.length">
          <ul class="list-group mb-3">
            <li
              class="list-group-item"
              v-for="item in cart.items"
              :key="item.productId._id"
            >
              <div class="d-flex justify-content-between align-items-center">
                <div>
                  {{ item.productId.name }}
                  <div class="small text-muted">Đơn giá: {{ item.productId.price.toLocaleString() }} đ</div>
                  <div class="d-flex align-items-center mt-1">
                    <button
                      class="btn btn-sm btn-outline-secondary"
                      @click="updateQuantity(item.productId._id, item.quantity - 1)"
                    >-</button>
                    <span class="mx-2">{{ item.quantity }}</span>
                    <button
                      class="btn btn-sm btn-outline-secondary"
                      @click="updateQuantity(item.productId._id, item.quantity + 1)"
                    >+</button>
                  </div>
                </div>
                <div class="fw-bold">
                  {{ (item.productId.price * item.quantity).toLocaleString() }} đ
                </div>
              </div>
            </li>
          </ul>

          <div class="mb-3">
            <label>Địa chỉ giao hàng:</label>
            <input type="text" class="form-control" v-model="shippingAddress" />
          </div>

          <div class="mb-3">
            <label>Số điện thoại:</label>
            <input type="text" class="form-control" v-model="phoneNumber" />
          </div>

          <div class="mb-3">
            <label class="form-label">Phương thức thanh toán:</label>
            <div class="payment-method-box p-3 rounded">
              <div class="form-check">
                <input
                  class="form-check-input"
                  type="radio"
                  name="paymentMethod"
                  value="COD"
                  v-model="paymentMethod"
                  id="payment-cod"
                />
                <label class="form-check-label" for="payment-cod">
                  <i class="bi bi-truck me-1"></i> Thanh toán khi nhận hàng
                  (COD)
                </label>
              </div>
            </div>
          </div>

          <div class="text-end">
            <button class="btn btn-success" @click="submitOrder">
              Đặt hàng
            </button>
          </div>
        </div>

        <div v-else>
          <p>Không có sản phẩm trong giỏ hàng.</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import axios from "axios";
import { useAuthStore } from "@/stores/auth";
import { useRouter } from "vue-router";
import Navbar from "@/components/Navbar.vue";

const auth = useAuthStore();
const router = useRouter();

const cart = ref(null);
const shippingAddress = ref("");
const phoneNumber = ref("");
const paymentMethod = ref("COD");

const fetchCart = async () => {
  try {
    const res = await axios.get(
      `http://localhost:5000/api/cart/${auth.user._id}`
    );
    cart.value = res.data;
  } catch (error) {
    alert("Không thể tải giỏ hàng.");
  }
};

const fetchUserProfile = async () => {
  try {
    const res = await axios.get("http://localhost:5000/api/users/me", {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("userToken")}`,
      },
    });
    shippingAddress.value = res.data.address || "";
    phoneNumber.value = res.data.phone || "";
  } catch (error) {
    console.error("Không thể tải thông tin người dùng:", error);
  }
};


const updateQuantity = async (productId, newQuantity) => {
  if (newQuantity < 1) return; // Không cho giảm dưới 1
  try {
    await axios.put(
      `http://localhost:5000/api/cart/update-quantity`,
      {
        userId: auth.user._id,
        productId,
        quantity: newQuantity,
      },
      {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("userToken")}`,
        },
      }
    );
    await fetchCart(); // Load lại giỏ sau khi update
  } catch (error) {
    console.error("Không thể cập nhật số lượng:", error);
    alert("Lỗi khi cập nhật số lượng.");
  }
};

const submitOrder = async () => {
  if (!shippingAddress.value.trim()) {
    return alert("Vui lòng nhập địa chỉ giao hàng.");
  }
  if (!phoneNumber.value.trim()) {
    return alert("Vui lòng nhập số điện thoại.");
  }

  try {
    const orderItems = cart.value.items.map((item) => ({
      product: item.productId._id,
      quantity: item.quantity,
      price: item.productId.price,
    }));

    const totalPrice = orderItems.reduce(
      (sum, item) => sum + item.quantity * item.price,
      0
    );

    const orderData = {
      user: auth.user._id, // giữ user id
      orderItems,
      shippingAddress: shippingAddress.value,
      phoneNumber: phoneNumber.value,
      totalPrice,
      paymentMethod: paymentMethod.value,
    };

    console.log("Dữ liệu gửi đi:", orderData);

    await axios.post("http://localhost:5000/api/users/orders", orderData, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("userToken")}`,
      },
    });

    alert("Đặt hàng thành công!");
    router.push("/orders");
  } catch (error) {
    console.error("Lỗi đặt hàng:", error.response?.data || error.message);
    alert(error.response?.data?.message || "Không thể đặt hàng.");
  }
};

onMounted(() => {
  if (!auth.user) {
    router.push("/login");
  } else {
    fetchUserProfile();
    fetchCart();
  }
});
</script>

<style scoped>
.payment-method-box {
  background-color: #f8f9fa;
  border: 1px solid #dee2e6;
}

.container {
  background-color: #c2f4cd;
  width: 80%;
  margin-top: 15px;
  border-radius: 10px;
}
</style>
