<template>
  <div>
    <div class="container mt-4" v-if="product">
      <div class="row">
        <div class="col-md-6">
          <img :src="product.image" class="img-fluid" />
        </div>
        <div class="col-md-6">
          <h2>{{ product.name }}</h2>
          <p class="fw-bold" style="color: #e04338">
            {{ product.price.toLocaleString() }} đ
          </p>
          <p>{{ product.description }}</p>

          <button
            class="my-btn mt-3 ms-2"
            style="color: #e04338"
            @click="addToCart(product._id)"
          >
            Thêm vào giỏ
          </button>
        </div>
      </div>
    </div>

    <!-- Đánh giá sản phẩm -->
    <div class="mt-5">
      <h5>Đánh giá</h5>
      <div v-if="reviews.length === 0">Chưa có đánh giá nào.</div>
      <div v-for="review in reviews" :key="review._id" class="border p-2 mb-2">
        <strong>{{ review.userId?.name }}</strong> - {{ review.rating }} sao
        <p class="mb-1">{{ review.comment }}</p>
        <div
          class="text-end"
          v-if="authUser && review.userId?._id === authUser._id"
        >
          <button
            class="btn btn-sm btn-outline-primary"
            @click="editReview(review)"
          >
            Chỉnh sửa
          </button>
        </div>
      </div>
    </div>

    <!-- Nút thêm đánh giá -->
    <div class="text-end mt-3" v-if="authUser && !userHasReviewed">
      <button class="btn btn-success" @click="prepareNewReview">
        Thêm đánh giá của bạn
      </button>
    </div>
  </div>

  <!-- Modal đánh giá -->
  <ReviewModal
    v-if="showEditModal"
    :productId="product._id"
    :existingReview="reviewBeingEdited"
    @close="handleModalClose"
  />
</template>

<script>
import axios from "axios";
import Navbar from "@/components/Navbar.vue";
import Footer from "@/components/Footer.vue";
import ReviewModal from "@/components/ReviewModal.vue";

export default {
  components: {
    Navbar,
    //Footer,
    ReviewModal,
  },
  data() {
    return {
      product: null,
      authUser: JSON.parse(localStorage.getItem("user")),
      showDesignModal: false,
      existingDesign: null,
      reviews: [],
      showEditModal: false,
      reviewBeingEdited: null,
      userHasReviewed: false, 
    };
  },
  async created() {
    await this.fetchProduct();
    await this.fetchReviews();

    const designId = this.$route.query.designId;
    if (designId) {
      await this.fetchExistingDesign(designId);
      this.showDesignModal = true;
    }
  },
  methods: {
    async fetchProduct() {
      const id = this.$route.params.id;
      try {
        const res = await axios.get(
          `http://localhost:5000/api/users/products/${id}`
        );
        this.product = res.data;
      } catch (err) {
        console.error("Lỗi khi lấy chi tiết sản phẩm:", err);
      }
    },

    async fetchReviews() {
      const id = this.$route.params.id;
      try {
        const res = await axios.get(
          `http://localhost:5000/api/users/reviews/product/${id}`
        );
        this.reviews = res.data;

        // Kiểm tra người dùng đã đánh giá chưa
        const userId = this.authUser?._id;
        this.userHasReviewed = this.reviews.some(
          (r) => r.userId?._id === userId
        );
      } catch (err) {
        console.error("Lỗi khi lấy đánh giá:", err);
      }
    },

    editReview(review) {
      this.reviewBeingEdited = review;
      this.showEditModal = true;
    },

    prepareNewReview() {
      this.reviewBeingEdited = null;
      this.showEditModal = true;
    },

    handleModalClose() {
      this.showEditModal = false;
      this.fetchReviews(); // cập nhật lại sau khi thêm/sửa review
    },

    async fetchExistingDesign(designId) {
      const token = localStorage.getItem("userToken");
      try {
        const res = await axios.get(
          `http://localhost:5000/api/users/design/${designId}`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        this.existingDesign = res.data;
      } catch (err) {
        console.error("Lỗi khi lấy thiết kế để chỉnh sửa:", err);
      }
    },

    async addToCart(productId) {
      const user = JSON.parse(localStorage.getItem("user"));
      const token = localStorage.getItem("userToken");

      if (!user || !token) {
        alert("Bạn cần đăng nhập để thêm vào giỏ hàng.");
        this.$router.push("/login");
        return;
      }

      try {
        await axios.post(
          `http://localhost:5000/api/cart/add`,
          {
            userId: user._id,
            productId: this.product._id,
            quantity: 1,
            price: this.product.price,
          },
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        alert("Đã thêm vào giỏ hàng!");
      } catch (err) {
        alert(
          "Lỗi khi thêm giỏ hàng: " +
            (err.response?.data?.message || err.message)
        );
      }
    },
  },
};
</script>
