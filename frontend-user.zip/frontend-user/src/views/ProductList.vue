<template>
  <div class="container my-4">
    <div class="row">
      <!-- Sidebar -->
      <div class="col-md-3">
        <Sidebar
          :selectedCategoryId="selectedCategoryId"
          @category-selected="handleCategoryFilter"
        />
      </div>

      <!-- Product list -->
      <div class="col-md-9">
        <h3 class="mb-4 text-start">
          <span @click="resetCategory" style="cursor: pointer">
            Sản phẩm
          </span>
          <span v-if="selectedCategoryName"> >> {{ selectedCategoryName }}</span>
        </h3>

        <div v-if="filteredProducts.length > 0" class="row">
          <ProductCard
            v-for="product in filteredProducts"
            :key="product._id"
            :product="product"
            @click="goToDetail(product._id)"
            @add-to-cart="handleAddToCart"
          />
        </div>

        <p v-else class="text-danger">Không có sản phẩm trong danh mục này.</p>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
import Sidebar from "@/components/Sidebar.vue";
import ProductCard from "@/components/ProductCard.vue";

export default {
  components: { Sidebar, ProductCard },
  data() {
    return {
      products: [],
      selectedCategoryId: null,
      selectedCategoryName: "",
    };
  },
  computed: {
    filteredProducts() {
      if (!this.selectedCategoryId) return this.products;
      return this.products.filter((p) => {
        if (!p.category) return false;
        const categoryId =
          typeof p.category === "object"
            ? p.category._id?.toString()
            : p.category.toString();
        return categoryId === this.selectedCategoryId;
      });
    },
  },
  methods: {
    async fetchProducts() {
      try {
        const res = await axios.get("http://localhost:5000/api/users/products");
        this.products = res.data;
      } catch (err) {
        console.error("Lỗi khi lấy sản phẩm:", err);
      }
    },
    handleCategoryFilter(category) {
      if (!category) {
        this.resetCategory();
        return;
      }
      this.selectedCategoryId = category._id?.toString();
      this.selectedCategoryName = category.name;
    },
    resetCategory() {
      this.selectedCategoryId = null;
      this.selectedCategoryName = "";
    },
    goToDetail(id) {
      this.$router.push({ name: "ProductDetail", params: { id } });
    },
    async handleAddToCart(product) {
      const user = JSON.parse(localStorage.getItem("user"));
      const token = localStorage.getItem("userToken");

      if (!user || !user._id || !token) {
        alert("Bạn cần đăng nhập để thêm vào giỏ hàng.");
        this.$router.push("/login");
        return;
      }

      try {
        await axios.post(
          "http://localhost:5000/api/cart/add",
          {
            userId: user._id,
            productId: product._id,
            quantity: 1,
            price: product.price,
          },
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        alert("✅ Đã thêm sản phẩm vào giỏ hàng!");
      } catch (err) {
        console.error(
          "❌ Lỗi thêm vào giỏ hàng:",
          err.response?.data || err.message
        );
        alert("Lỗi khi thêm sản phẩm!");
      }
    },
  },
  mounted() {
    this.fetchProducts();
  },
};
</script>
