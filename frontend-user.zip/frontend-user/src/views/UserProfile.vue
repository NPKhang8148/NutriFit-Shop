<template>
  <div>
    <Navbar />
    
    <div class="user-bg-wrapper py-5">
      <div class="container">
        <div class="card-box mx-auto p-4">
          <h2 class="text-center fw-bold pb-3" style="color: #e04338">
            THÔNG TIN NGƯỜI DÙNG
          </h2>

          <div v-if="user && !isEditing">
            <p><strong>Họ tên:</strong> {{ user.name }}</p>
            <p><strong>Email:</strong> {{ user.email }}</p>
            <p>
              <strong>Giới tính:</strong> {{ user.gender || "Chưa cập nhật" }}
            </p>
            <p>
              <strong>Số điện thoại:</strong>
              {{ user.phone || "Chưa cập nhật" }}
            </p>
            <p>
              <strong>Địa chỉ:</strong> {{ user.address || "Chưa cập nhật" }}
            </p>
            <button @click="startEditing" class="btn btn-outline-primary mt-2">
              Cập nhật thông tin
            </button>
            <button
              @click="deleteAccount"
              class="btn btn-outline-danger mt-2 ms-1"
            >
              Xóa tài khoản
            </button>
          </div>

          <div v-else-if="user && isEditing">
            <form @submit.prevent="updateInfo">
              <div class="mb-3">
                <label class="form-label">Họ tên</label>
                <input v-model="form.name" class="form-control" type="text" />
              </div>
              <div class="mb-3">
                <label class="form-label">Giới tính</label>
                <select v-model="form.gender" class="form-control">
                  <option value="">-- Chọn --</option>
                  <option value="Nam">Nam</option>
                  <option value="Nữ">Nữ</option>
                  <option value="Khác">Khác</option>
                </select>
              </div>
              <div class="mb-3">
                <label class="form-label">Số điện thoại</label>
                <input v-model="form.phone" class="form-control" type="text" />
              </div>
              <div class="mb-3">
                <label class="form-label">Địa chỉ</label>
                <input
                  v-model="form.address"
                  class="form-control"
                  type="text"
                />
              </div>
              <button type="submit" class="my-btn me-2">Lưu thay đổi</button>
              <button
                type="button"
                @click="cancelEdit"
                class="btn btn-secondary"
              >
                Hủy
              </button>
            </form>
          </div>

          <div v-else>
            <p>Đang tải dữ liệu người dùng...</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from "vue";
import axiosInstance from "@/stores/axiosInstance";
import Navbar from "@/components/Navbar.vue";
import Footer from "@/components/Footer.vue";

const user = ref(null);
const isEditing = ref(false);
const form = reactive({
  name: "",
  gender: "",
  phone: "",
  address: "",
});

const fetchUserInfo = async () => {
  try {
    const res = await axiosInstance.get("/users/me");
    user.value = res.data;
    Object.assign(form, res.data);
  } catch (error) {
    console.error("Lỗi khi lấy thông tin người dùng:", error);
  }
};

const startEditing = () => {
  isEditing.value = true;
};

const cancelEdit = () => {
  isEditing.value = false;
  Object.assign(form, user.value); // reset
};

const updateInfo = async () => {
  try {
    await axiosInstance.put("/users/update", form);
    await fetchUserInfo(); // cập nhật
    isEditing.value = false;
    alert("Cập nhật thành công!");
  } catch (error) {
    console.error("Lỗi cập nhật thông tin:", error);
    alert("Cập nhật thất bại!");
  }
};

const deleteAccount = async () => {
  const confirmDelete = confirm(
    "Bạn có chắc chắn muốn xóa tài khoản không? Hành động này không thể hoàn tác!"
  );
  if (!confirmDelete) return;

  try {
    await axiosInstance.delete("/users/delete-account");
    alert("Tài khoản của bạn đã bị xóa.");

    // Xóa token & chuyển hướng về trang chủ hoặc đăng nhập
    localStorage.removeItem("userToken");
    window.location.href = "/home";
  } catch (error) {
    console.error("Lỗi khi xóa tài khoản:", error);
    alert("Xóa tài khoản thất bại. Vui lòng thử lại.");
  }
};

onMounted(() => {
  fetchUserInfo();
});
</script>

<style scoped>
.user-bg-wrapper {
  min-height: 100vh;
  background: url("../assets/bggym3.jpg") no-repeat center center;
  background-size: cover;
  display: flex;
  /* align-items: center; */
  justify-content: center;
}

.card-box {
  background-color: #fff;
  border: 1px solid #ddd;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  max-width: 600px;
  width: 100%;
}
</style>
