<template>
  <div>
    <Navbar />

    <div class="login-container">
      <div class="login-box">
        <h2 class="text-center text-success fw-bold pb-3">ĐĂNG NHẬP</h2>
        <form @submit.prevent="handleLogin">
          <div class="mb-3">
            <label for="email" class="form-label fw-bold">Email:</label>
            <input
              type="email"
              class="form-control"
              id="email"
              v-model="email"
              @blur="validateEmail"
              required
            />
            <p v-if="emailError" class="text-danger">{{ emailError }}</p>
          </div>

          <div class="mb-3">
            <label for="password" class="form-label fw-bold">Mật khẩu:</label>
            <div class="input-group">
              <input
                :type="showPassword ? 'text' : 'password'"
                class="form-control"
                id="password"
                v-model="password"
                @blur="validatePassword"
                required
              />
              <button
                type="button"
                class="btn btn-outline-secondary"
                @click="togglePassword"
              >
                {{ showPassword ? "Ẩn" : "Hiện" }}
              </button>
            </div>
            <p v-if="passwordError" class="text-danger">{{ passwordError }}</p>
          </div>

          <div class="text-center">
            <button
              type="submit"
              class="btn btn-success w-100"
              :disabled="loading"
            >
              <span
                v-if="loading"
                class="spinner-border spinner-border-sm"
              ></span>
              Đăng nhập
            </button>
          </div>
          <p v-if="errorMessage" class="text-danger text-center mt-2">
            {{ errorMessage }}
          </p>
        </form>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
import Navbar from "@/components/Navbar.vue";
import Footer from "@/components/Footer.vue";

export default {
  components: {
    Navbar,
    //Footer,
  },
  data() {
    return {
      email: "",
      password: "",
      emailError: "",
      passwordError: "",
      errorMessage: "",
      loading: false,
      showPassword: false,
    };
  },
  methods: {
    validateEmail() {
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      this.emailError = emailPattern.test(this.email)
        ? ""
        : "Email không hợp lệ!";
    },
    validatePassword() {
      this.passwordError =
        this.password.length < 6 ? "Mật khẩu phải có ít nhất 6 ký tự!" : "";
    },
    togglePassword() {
      this.showPassword = !this.showPassword;
    },
    async handleLogin() {
      this.validateEmail();
      this.validatePassword();

      if (this.emailError || this.passwordError) return;

      this.loading = true;
      this.errorMessage = "";

      try {
        const res = await axios.post("http://localhost:5000/api/users/login", {
          email: this.email,
          password: this.password,
        });

        if (res.data && res.data.token) {
          const user = res.data.user;
          // chuẩn hóa key: đổi id thành _id
          user._id = user.id;
          delete user.id;

          localStorage.setItem("userToken", res.data.token);
          localStorage.setItem("user", JSON.stringify(user));

          //alert("Đăng nhập thành công!");
          this.$router.push("/home");
        }
      } catch (error) {
        this.errorMessage =
          error.response?.data?.message ||
          "Đăng nhập thất bại. Vui lòng thử lại!";
      } finally {
        this.loading = false;
      }
    },
  },
};
</script>

<style scoped>
.login-container {
  background: url("@/assets/bggym3.jpg") no-repeat center center/cover;
  height: 90vh;
  display: flex;
  justify-content: center;
  align-items: center;
}

.login-box {
  background: rgba(228, 255, 239, 0.9);
  padding: 30px;
  border-radius: 10px;
  box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
  width: 400px;
  border: 2px solid #ccc;
}
</style>
