<template>
  <div class="min-h-screen flex flex-col">
    <Navbar />

    <div>
      <div
        class="flex-grow register-container d-flex align-items-center justify-content-center"
      >
        <div
          class="register-box bg-white p-4 rounded shadow w-100"
          style="max-width: 500px"
        >
          <h2 class="text-center text-success fw-bold pb-3">ĐĂNG KÝ</h2>
          <form @submit.prevent="handleRegister">
            <div class="mb-3">
              <label for="name" class="form-label fw-bold">Tên đầy đủ</label>
              <input
                type="text"
                class="form-control"
                id="name"
                v-model="name"
                required
              />
            </div>
            <div class="mb-3">
              <label for="email" class="form-label fw-bold">Email</label>
              <input
                type="email"
                class="form-control"
                id="email"
                v-model="email"
                @blur="validateEmail"
                required
              />
              <p v-if="emailError" class="text-danger">{{ emailError }}</p>
            </div>
            <!-- Password -->
            <div class="mb-3">
              <label for="password" class="form-label fw-bold">Mật khẩu</label>
              <div class="input-group">
                <input
                  :type="showPassword ? 'text' : 'password'"
                  class="form-control"
                  id="password"
                  v-model="password"
                  @blur="validatePassword"
                  required
                />
                <button
                  class="btn btn-outline-secondary"
                  type="button"
                  @click="showPassword = !showPassword"
                >
                  <i
                    :class="showPassword ? 'bi bi-eye-slash' : 'bi bi-eye'"
                  ></i>
                </button>
              </div>
              <p v-if="passwordError" class="text-danger">
                {{ passwordError }}
              </p>
            </div>

            <!-- Vai trò -->
            <div class="mb-3">
              <label for="role" class="form-label fw-bold">Vai trò</label>
              <select id="role" v-model="role" class="form-select" required>
                <option value="buyer">Người mua</option>
                <option value="shipper">Người giao hàng</option>
              </select>
            </div>

            <div class="text-center">
              <button type="submit" class="btn btn-success w-50">
                Đăng ký
              </button>
            </div>

            <p v-if="errorMessage" class="text-danger text-center mt-2">
              {{ errorMessage }}
            </p>
          </form>

          <p class="mt-3 text-center">
            Đã có tài khoản? <router-link to="/login">Đăng nhập</router-link>
          </p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from "vue";
import axios from "axios";
import { useRouter } from "vue-router";
import Navbar from "@/components/Navbar.vue";
import Footer from "@/components/Footer.vue";

const router = useRouter();

const name = ref("");
const email = ref("");
const password = ref("");

const emailError = ref("");
const passwordError = ref("");
const errorMessage = ref("");
const role = ref("buyer"); // mặc định là người mua
const showPassword = ref(false);

const validateEmail = () => {
  const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  emailError.value = pattern.test(email.value) ? "" : "Email không hợp lệ";
};

const validatePassword = () => {
  passwordError.value =
    password.value.length >= 6 ? "" : "Mật khẩu phải ít nhất 6 ký tự";
};

const handleRegister = async () => {
  if (emailError.value || passwordError.value) return;

  try {
    await axios.post("http://localhost:5000/api/users/register", {
      name: name.value,
      email: email.value,
      password: password.value,
      role: "user", // luôn là 'user'
      //userType: role.value,     // 'buyer' hoặc 'shipper'
    });
    alert("Đăng ký thành công!");
    router.push("/login");
  } catch (err) {
    errorMessage.value = "Đăng ký thất bại!";
  }
};
</script>

<style scoped>
.register-container {
  padding-top: 40px;
  padding-bottom: 40px;
  min-height: 100vh;
  background: url("@/assets/bggym2.jpg") no-repeat center center;
  background-size: cover;
}
</style>
