<template>
  <div class="layout-wrapper d-flex flex-column min-vh-100">
    <Navbar />

    <div class="container py-4 flex-grow-1">
      <h2 class="mb-4">Đơn hàng của bạn</h2>

      <div v-if="orders.length > 0">
        <div
          v-for="order in orders"
          :key="order._id"
          class="card mb-3 shadow-sm"
        >
          <div class="card-body">
            <p><strong>Mã đơn:</strong> {{ order._id }}</p>
            <p>
              <strong>Ngày đặt:</strong>
              {{ new Date(order.createdAt).toLocaleString() }}
            </p>
            <p>
              <strong>Trạng thái:</strong>
              <span :class="statusClass(order.status)">{{ order.status }}</span>
            </p>
            <p>
              <strong>Tổng tiền:</strong>
              {{ order.totalPrice.toLocaleString() }} đ
            </p>

            <div class="d-flex justify-content-end gap-2">
              <router-link
                :to="`/orders/${order._id}`"
                class="btn btn-outline-primary btn-sm"
              >
                Xem chi tiết
              </router-link>

              <button
                v-if="order.status === 'Chờ xác nhận'"
                class="btn btn-outline-danger btn-sm"
                @click="cancelOrder(order._id)"
              >
                Hủy đơn
              </button>
            </div>
          </div>
        </div>
      </div>

      <div v-else>
        <p>Bạn chưa có đơn hàng nào.</p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import axios from "axios";
import { useAuthStore } from "@/stores/auth";
import { useRouter } from "vue-router";
import Navbar from "@/components/Navbar.vue";
import Footer from "@/components/Footer.vue";

const orders = ref([]);
const auth = useAuthStore();
const router = useRouter();

const fetchOrders = async () => {
  // console.log("🔐 Token auth:", auth.token)
  try {
    const res = await axios.get("http://localhost:5000/api/users/orders", {
      headers: {
        Authorization: `Bearer ${auth.token}`,
      },
    });
    orders.value = res.data;
  } catch (error) {
    console.error(error);
    alert("Không thể tải danh sách đơn hàng.");
  }
};

const cancelOrder = async (orderId) => {
  if (!confirm("Bạn có chắc muốn hủy đơn hàng này?")) return;

  try {
    await axios.put(
      `http://localhost:5000/api/users/orders/${orderId}/cancel`,
      {},
      {
        headers: {
          Authorization: `Bearer ${auth.token}`,
        },
      }
    );
    alert("Đã hủy đơn hàng.");
    fetchOrders();
  } catch (error) {
    alert("Hủy đơn không thành công.");
  }
};

const statusClass = (status) => {
  switch (status) {
    case "Chờ xác nhận":
      return "text-warning";
    case "Đã xác nhận":
    case "Đang giao":
    case "Chờ xử lý":
      return "text-primary";
    case "Hoàn thành":
      return "text-success";
    case "Đã hủy":
      return "text-danger";
    default:
      return "";
  }
};

onMounted(() => {
  if (!auth.user) {
    router.push("/login");
  } else {
    fetchOrders();
  }
});
</script>

<style scoped>
.layout-wrapper {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}
</style>
