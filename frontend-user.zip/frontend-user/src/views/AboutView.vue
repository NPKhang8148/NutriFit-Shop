<template>
  <div>
    <Navbar />

    <div class="about container">
      <h1>Nutri Fit - Uy Tín 1 Thập Kỷ, 10 Năm 1 Hành Trình</h1>
      <!-- <p><strong>Đăng bởi:</strong> Nguyễn Mỹ Linh - Ngày 22-02-2024</p> -->

      <img
        class="banner-image"
        src="/src/assets/426489784_805453111605360_4217767326760994876_n-1400x790.jpg"
        alt="Nutri Fit banner"
      />

      <h2>Nutri Fit - UY TÍN MỘT THẬP KỶ</h2>
      <p>
        Với 10 năm kinh nghiệm, Nutri Fit tự hào là một trong những đơn vị hàng đầu
        trong lĩnh vực phân phối thực phẩm thể hình và thực phẩm bổ sung tăng cường sức khỏe.
      </p>
      <p>
        Sau 10 năm kể từ khi khai trương cửa hàng đầu tiên tại Hà Nội, Nutri Fit đã phát triển
        7 chi nhánh tại Hà Nội, Đà Nẵng và TP.HCM, phục vụ hơn 300.000 lượt khách mỗi năm
        với tốc độ tăng trưởng khoảng 18%.
      </p>
      <p>
        Nutri Fit không chỉ là nơi cung cấp sản phẩm mà còn là cộng đồng chia sẻ kiến thức
        thể hình và dinh dưỡng khoa học.
      </p>

      <img
        class="section-image"
        src="/src/assets/cua-hang-ban-whey-uy-tin-o-hcm-2.webp"
        alt="Hình ảnh cửa hàng Nutri Fit"
      />

      <h2>1000+ SẢN PHẨM DINH DƯỠNG THỂ HÌNH CHÍNH HÃNG</h2>
      <p>
        Nutri Fit cung cấp whey protein, mass gainer, creatine, fat burner,...
        được nhập khẩu từ Mỹ, Anh, Ba Lan, Úc, Châu Âu. Tất cả sản phẩm có nguồn gốc rõ ràng,
        tem mác đầy đủ và được cấp phép bởi cơ quan kiểm định.
      </p>
      <p>
        Các thương hiệu nổi tiếng như Nutrabolics, Dymatize, Optimum Nutrition,...
        đều có mặt tại Nutri Fit với mức giá đa dạng, phù hợp với mọi đối tượng khách hàng.
      </p>

      <img
        class="section-image"
        src="/src/assets/wheystore-thuc-pham-the-hinh-1.webp"
        alt="Hệ thống cửa hàng Nutri Fit"
      />

      <h2>HỆ THỐNG MUA SẮM ONLINE - OFFLINE TIỆN LỢI</h2>
      <p>Nutri Fit hiện có 7 chi nhánh:</p>
      <ul>
        <li>125 Lê Thanh Nghị, Hai Bà Trưng, Hà Nội</li>
        <li>17 Xuân Thủy, Cầu Giấy, Hà Nội</li>
        <li>21 Trần Phú, Hà Đông, Hà Nội</li>
        <li>51 Trần Quốc Hoàn, Tân Bình, TP.HCM</li>
        <li>391 Nguyễn Trãi, quận 5, TP.HCM</li>
        <li>218 Bạch Đằng, Bình Thạnh, TP.HCM</li>
        <li>450 Hoàng Diệu, Hải Châu, Đà Nẵng</li>
      </ul>
      <p>
        Đến bất kỳ chi nhánh nào, khách hàng đều được đo InBody miễn phí và tư vấn tận tình
        về dinh dưỡng và tập luyện.
      </p>
      <p>
        Nutri Fit có mặt trên Shopee, Lazada, Tiktok Shop, Website với nhiều ưu đãi hấp dẫn,
        giúp bạn mua sắm dễ dàng dù ở bất kỳ đâu.
      </p>

      <h2>CHẾ ĐỘ BẢO HÀNH ĐẢM BẢO LỢI ÍCH TỐI ĐA CHO KHÁCH HÀNG</h2>
      <p>
        Nutri Fit hỗ trợ đổi trả trong 30 ngày nếu sản phẩm còn nguyên vẹn và có hóa đơn đi kèm.
        Đồng thời hỗ trợ thanh lý sản phẩm tùy trường hợp.
      </p>
      <p>
        Chúng tôi cam kết chất lượng sản phẩm, luôn đặt sức khỏe khách hàng lên hàng đầu.
        Nutri Fit mong muốn trở thành người bạn đồng hành lâu dài trong hành trình cải thiện vóc dáng
        và duy trì cơ thể khỏe mạnh.
      </p>

      <p><strong>Hotline tư vấn đặt hàng: 0919013030</strong></p>
    </div>

    
  </div>
</template>

<script setup>
import Navbar from "@/components/Navbar.vue"
//import Footer from "@/components/Footer.vue"
</script>

<style scoped>
.container {
  max-width: 800px;
  margin: 0 auto;
  padding: 2rem;
}

h1, h2 {
  color: #2c3e50;
  margin-top: 1.5rem;
}

p {
  line-height: 1.6;
  margin-bottom: 1rem;
}

ul {
  padding-left: 1.5rem;
  margin-bottom: 1rem;
}

.banner-image {
  width: 100%;
  height: auto;
  margin: 1.5rem 0;
  border-radius: 12px;
  box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

.section-image {
  width: 100%;
  height: auto;
  margin: 1rem 0 2rem 0;
  border-radius: 10px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.08);
}
</style>
