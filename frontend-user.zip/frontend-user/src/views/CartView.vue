<template>
  <div class="layout-wrapper d-flex flex-column min-vh-100">
    <Navbar />

    <div class="container py-5 flex-grow-1">
      <h2>🛒 Giỏ hàng của bạn</h2>

      <div v-if="cart && cart.items.length">
        <div
          v-for="item in cart.items"
          :key="item.productId._id"
          class="card mb-3"
        >
          <div
            class="card-body d-flex justify-content-between align-items-center flex-wrap"
          >
            <div>
              <h5>{{ item.productId.name }}</h5>
              <div class="d-flex align-items-center">
                <button
                  class="btn btn-sm btn-outline-secondary me-2"
                  @click="updateQuantity(item.productId._id, item.quantity - 1)"
                  :disabled="item.quantity <= 1"
                >
                  ➖
                </button>
                <span>{{ item.quantity }}</span>
                <button
                  class="btn btn-sm btn-outline-secondary ms-2"
                  @click="updateQuantity(item.productId._id, item.quantity + 1)"
                >
                  ➕
                </button>
              </div>
            </div>

            <p class="fw-bold mt-4">
              Tổng: {{ (item.productId.price * item.quantity).toLocaleString() }} đ
            </p>

            <button
              class="btn btn-danger"
              @click="removeFromCart(item.productId._id)"
            >
              ❌ Xoá
            </button>
          </div>
        </div>

        <!-- Mã giảm giá -->
        <div class="mt-4 p-3 border rounded">
          <h5>🎟 Mã giảm giá</h5>
          <div class="d-flex">
            <input
              v-model="couponCode"
              class="form-control me-2"
              placeholder="Nhập mã giảm giá..."
            />
            <button class="btn btn-primary" @click="applyCoupon">
              Áp dụng
            </button>
          </div>
          <p v-if="discount > 0" class="text-success mt-2">
            ✅ Giảm {{ discount.toLocaleString() }} đ
          </p>
          <p v-if="couponError" class="text-danger mt-2">
            ❌ {{ couponError }}
          </p>
        </div>
      </div>

      <div v-else>
        <p>Giỏ hàng đang trống.</p>
      </div>

      <!-- Tổng tiền -->
      <div v-if="cart && cart.items.length" class="text-end mt-4">
        <h4 class="text-success">
          Tổng cộng: {{ finalPrice.toLocaleString() }} đ
        </h4>
      </div>
    </div>

    <!-- Nút đặt hàng -->
    <div class="text-end mt-3" v-if="cart && cart.items.length">
      <router-link to="/checkout" class="btn btn-success">
        💳 Tiến hành đặt hàng
      </router-link>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from "vue";
import axios from "axios";
import { useAuthStore } from "@/stores/auth";
import { useRouter } from "vue-router";
import Navbar from "@/components/Navbar.vue";

const router = useRouter();
const auth = useAuthStore();

const cart = ref(null);
const couponCode = ref("");
const discount = ref(0);
const couponError = ref("");

onMounted(() => {
  if (!auth.user) {
    router.push("/login");
  } else {
    fetchCart();
  }
});

const fetchCart = async () => {
  const res = await axios.get(`http://localhost:5000/api/cart/${auth.user._id}`);
  cart.value = res.data;
};

const removeFromCart = async (productId) => {
  await axios.post("http://localhost:5000/api/cart/remove", {
    userId: auth.user._id,
    productId,
  });
  fetchCart();
};

const updateQuantity = async (productId, newQuantity) => {
  if (newQuantity < 1) return;
  await axios.post("http://localhost:5000/api/cart/update", {
    userId: auth.user._id,
    productId,
    quantity: newQuantity,
  });
  fetchCart();
};

const totalPrice = computed(() => {
  if (!cart.value) return 0;
  return cart.value.items.reduce((sum, item) => {
    return sum + item.productId.price * item.quantity;
  }, 0);
});

const finalPrice = computed(() => {
  return totalPrice.value - discount.value;
});

const applyCoupon = async () => {
  couponError.value = "";
  discount.value = 0;

  try {
    const res = await axios.post("http://localhost:5000/api/coupons/apply", {
      code: couponCode.value,
      total: totalPrice.value,
    });
    discount.value = res.data.discountAmount;
  } catch (err) {
    couponError.value = err.response?.data?.message || "Mã giảm giá không hợp lệ.";
  }
};
</script>

<style scoped>
.layout-wrapper {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}
</style>
