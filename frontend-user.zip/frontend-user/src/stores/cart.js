import { defineStore } from "pinia";
import axios from "axios";

export const useCartStore = defineStore("cart", {
  state: () => ({
    items: [],
  }),
  actions: {
    async fetchCart() {
      try {
        const res = await axios.get("/api/cart");
        this.items = res.data.items || [];
      } catch (err) {
        console.error("Lỗi lấy giỏ hàng:", err);
      }
    },
  },
});
