<!-- <template>
  <div id="app">
    <Header />
    <div class="main-wrapper">
      <main class="main-content">
        <router-view />
      </main>
      <Footer />
    </div>
  </div>
</template>

<script>
import Header from "./components/Header.vue";
import Footer from "./components/Footer.vue";

export default {
  components: {
    Header,
    Footer,
  },
};
</script>

<style>
html,
body {
  margin: 0;
  padding: 0;
  height: 100%;
  background-color: #1e1e1e;
}

#app {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

.main-wrapper {
  flex: 1; /* Đảm bảo wrapper chiếm toàn bộ không gian còn lại */
  display: flex;
  flex-direction: column;
}

.main-content {
  flex: 1; /* Đảm bảo nội dung chính chiếm toàn bộ không gian trống */
  padding-top: 70px; /* tránh bị Header đè lên */
}

/* Ẩn phần footer-wrapper không cần thiết */
/* Xóa hoặc comment lại đoạn code này */
/* .footer-wrapper {
  width: 100vw;
  background-color: #2a2d2f;
} */

/* Xóa margin/padding mặc định nếu cần */
* {
  box-sizing: border-box;
}
</style> -->

<!-- tạm ổn -->
<template>
  <div>
    <Header />
    <Navbar />
    <router-view />
    <Footer />
  </div>
</template>

<script setup>
import Header from "./components/Header.vue";
import Navbar from "./components/Navbar.vue";
import Footer from "./components/Footer.vue";
</script>

<style>
body {
  font-family: "Nunito", sans-serif;
  margin: 0;
  padding: 0;
}
</style>

<!-- <template>
  <div id="app">
    <Header />
    <Navbar />
    <main class="main-content">
      <router-view />
    </main>
    <Footer />
  </div>
</template>

<script setup>
import Header from './components/Header.vue';
import Navbar from './components/Navbar.vue';
import Footer from './components/Footer.vue';
</script>

<style>
html, body, #app {
  height: 100%; 
  margin: 0;
}

#app {
  display: flex;
  flex-direction: column;
  min-height: 100vh; /* Chiều cao toàn màn hình */
}

.main-content {
  flex: 1; /* Đẩy footer xuống đáy khi nội dung ít */
}

body {
  font-family: 'Nunito', sans-serif;
  background-color: white;
}
</style> -->
