<template>
  <div class="card shadow-sm">
    <div class="card-header text-white fw-bold" style="background-color: #0CB58A;">
      Danh mục sản phẩm
    </div>
    <ul class="list-group list-group-flush">
      <!-- Mục tất cả sản phẩm -->
      <li
        class="list-group-item list-group-item-action"
        :class="{ active: !selectedCategoryId }"
        @click="$emit('category-selected', null)"
        style="cursor: pointer;"
      >
        Tất cả sản phẩm
      </li>

      <!-- Danh sách danh mục -->
      <li
        v-for="category in categories"
        :key="category._id"
        class="list-group-item list-group-item-action"
        :class="{ active: selectedCategoryId === category._id }"
        @click="$emit('category-selected', category)"
        style="cursor: pointer;"
      >
        {{ category.name }}
      </li>

      <!-- Khi không có danh mục -->
      <li v-if="categories.length === 0" class="list-group-item text-center">
        Không có danh mục nào.
      </li>
    </ul>
  </div>
</template>

<script>
import axios from "axios";

export default {
  props: {
    selectedCategoryId: {
      type: String,
      default: null,
    },
  },
  data() {
    return {
      categories: [],
    };
  },
  async created() {
    try {
      const res = await axios.get("http://localhost:5000/api/categories");
      // Sắp xếp danh mục theo tên
      this.categories = res.data.sort((a, b) =>
        a.name.localeCompare(b.name, "vi", { sensitivity: "base" })
      );
    } catch (err) {
      console.error("Lỗi khi lấy danh mục:", err);
    }
  },
};
</script>

<style scoped>
.active {
  background-color: #55e9c9 !important;
  color: white !important;
}
</style>
