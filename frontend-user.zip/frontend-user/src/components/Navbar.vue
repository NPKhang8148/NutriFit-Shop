<template>
  <nav
    class="navbar navbar-expand-lg navbar-light bg-success shadow-sm px-4 w-100 position-fixed top-0 start-0"
    style="z-index: 1050"
  >
    <div class="container-fluid">
      <!-- Logo -->
      <router-link
        class="navbar-brand fw-bold text-white d-flex align-items-center"
        :to="{ name: 'Home' }"
      >
        <img
          src="@/assets/logonutrifit.jpg"
          alt="Nutri Fit"
          width="40"
          class="me-2 rounded-circle"
        />
        NUTRI FIT
      </router-link>

      <!-- Toggle (mobile) -->
      <button
        class="navbar-toggler"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#navbarSupportedContent"
      >
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Nội dung navbar -->
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ms-auto mb-2 mb-lg-0 me-3">
          <li class="nav-item">
            <router-link class="nav-link text-white" to="/about"
              >Giới thiệu</router-link
            >
          </li>
          <li class="nav-item">
            <router-link class="nav-link text-white" to="/products"
              >Sản phẩm</router-link
            >
          </li>

          <!-- Nếu chưa đăng nhập -->
          <template v-if="!isLoggedIn">
            <li class="nav-item">
              <router-link class="nav-link text-white" to="/register"
                >Đăng ký</router-link
              >
            </li>
            <li class="nav-item">
              <router-link class="nav-link text-white" to="/login"
                >Đăng nhập</router-link
              >
            </li>
          </template>

          <!-- Nếu đã đăng nhập -->
          <template v-else>
            <li class="nav-item d-flex align-items-center text-warning fw-bold">
              <el-avatar :size="30" class="me-2">{{ avatarInitial }}</el-avatar>
              👋 Chào, {{ userName }}
            </li>
            <li class="nav-item">
              <el-button type="danger" size="small" @click="handleLogout"
                >Đăng xuất</el-button
              >
            </li>
            <li class="nav-item">
              <router-link class="nav-link text-white" to="/profile"
                >Tài khoản</router-link
              >
            </li>
            <li class="nav-item">
              <router-link class="nav-link text-white" to="/cart">
                <!-- <el-badge :value="cartCount" class="item"> -->
                  Giỏ hàng
                <!-- </el-badge> -->
              </router-link>
            </li>
            <li class="nav-item">
              <router-link class="nav-link text-white" to="/orders"
                >Đơn hàng</router-link
              >
            </li>
          </template>
        </ul>

        <!-- Search box -->
        <form class="d-flex me-3" @submit.prevent="handleSearch">
          <el-input
            v-model="searchKeyword"
            placeholder="Tìm kiếm..."
            clearable
            size="small"
            class="me-2"
          />
          <el-button type="primary" size="small" @click="handleSearch">
            <el-icon><Search /></el-icon>
          </el-button>
        </form>
      </div>
    </div>
  </nav>
</template>

<script>
import { useAuthStore } from "@/stores/auth";
import { useCartStore } from "@/stores/cart"; // <-- Thêm store giỏ hàng
import { ElAvatar, ElInput, ElButton, ElBadge } from "element-plus";
import { Search } from "@element-plus/icons-vue";

export default {
  components: {
    ElAvatar,
    ElInput,
    ElButton,
    ElBadge,
    Search,
  },
  data() {
    return {
      searchKeyword: "",
    };
  },
  computed: {
    auth() {
      return useAuthStore();
    },
    cart() {
      return useCartStore();
    },
    isLoggedIn() {
      return this.auth.user !== null;
    },
    userName() {
      return this.auth.user?.name || this.auth.user?.email || "";
    },
    avatarInitial() {
      return this.userName ? this.userName[0].toUpperCase() : "?";
    },
    cartCount() {
      return this.cart.items.length; // Lấy số lượng sản phẩm từ store
    },
  },
  mounted() {
    // Khi load Navbar sẽ gọi API để lấy giỏ hàng
    if (this.isLoggedIn) {
      this.cart.fetchCart();
    }
  },
  methods: {
    handleSearch() {
      const keyword = this.searchKeyword.trim();
      if (!keyword) return;
      this.$router.push({ name: "SearchResult", query: { search: keyword } });
    },
    handleLogout() {
      this.auth.logout();
      this.$router.push("/");
    },
  },
};
</script>

<style scoped>
.navbar-brand img {
  vertical-align: middle;
}
.navbar .nav-link:hover {
  text-decoration: underline;
  color: #ffeb99 !important;
}
.item {
  --el-badge-size: 14px;
}
</style>
