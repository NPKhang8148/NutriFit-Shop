<!-- <template>
  <div class="modal-mask">
    <div class="modal-wrapper">
      <div class="modal-container">
        <h5 class="modal-title text-center mb-3">
          {{ existingReview ? "Chỉnh sửa đánh giá" : "Thêm đánh giá của bạn" }}
        </h5>

        <div class="form-group">
          <label>Đánh giá sao:</label>
          <select v-model="form.rating" class="form-control">
            <option v-for="n in 5" :key="n" :value="n">{{ n }} sao</option>
          </select>
        </div>

        <div class="form-group mt-3">
          <label>Bình luận:</label>
          <textarea v-model="form.comment" class="form-control" rows="3" />
        </div>

        <div class="mt-3 text-end">
          <button class="btn btn-secondary me-2" @click="$emit('close')">
            Hủy
          </button>
          <button class="btn btn-success" @click="submitReview">Lưu</button>
        </div>
      </div>
    </div>
  </div>
</template> -->

<!-- <script>
import axios from "axios";

export default {
  props: {
    productId: { type: String, required: true },
    existingReview: { type: Object, default: null },
  },
  data() {
    return {
      form: {
        rating: this.existingReview?.rating || 5,
        comment: this.existingReview?.comment || "",
      },
    };
  },
  methods: {
    async submitReview() {
      const token = localStorage.getItem("userToken");

      try {
        if (this.existingReview) {
          // Cập nhật đánh giá
          await axios.put(
            `http://localhost:5000/api/users/reviews/${this.existingReview._id}`,
            {
              rating: this.form.rating,
              comment: this.form.comment,
            },
            {
              headers: {
                Authorization: `Bearer ${token}`,
              },
            }
          );
          alert("✅ Đã cập nhật đánh giá!");
        } else {
          // Tạo đánh giá mới
          const orderId = localStorage.getItem("reviewOrderId");
          if (!orderId) {
            alert("Không tìm thấy đơn hàng để đánh giá.");
            return;
          }

          await axios.post(
            `http://localhost:5000/api/users/reviews`,
            {
              productId: this.productId,
              rating: this.form.rating,
              comment: this.form.comment,
              orderId,
            },
            {
              headers: {
                Authorization: `Bearer ${token}`,
              },
            }
          );
          alert("✅ Đã gửi đánh giá!");
        }

        this.$emit("close");
      } catch (err) {
        console.error("Lỗi đánh giá:", err);
        alert("❌ Gửi đánh giá thất bại!");
      }
    },
  },
};
</script>

<style scoped>
.modal-mask {
  position: fixed;
  z-index: 9998;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.4);
  display: flex;
  align-items: center;
  justify-content: center;
}
.modal-wrapper {
  width: 100%;
  max-width: 500px;
}
.modal-container {
  background: white;
  padding: 20px;
  border-radius: 8px;
}
</style> -->

<template>
  <div class="modal">
    <div class="modal-content">
      <h3>{{ existingReview ? "Chỉnh sửa đánh giá" : "Đánh giá sản phẩm" }}</h3>
      <form @submit.prevent="handleSubmit">
        <label>Đánh giá:</label>
        <select v-model.number="rating" required>
          <option disabled value="">Chọn sao</option>
          <option v-for="n in 5" :key="n" :value="n">{{ n }} sao</option>
        </select>

        <label>Bình luận:</label>
        <textarea
          v-model="comment"
          placeholder="Nhận xét của bạn..."
          required
        ></textarea>

        <button type="submit">
          {{ existingReview ? "Cập nhật" : "Gửi đánh giá" }}
        </button>
        <button type="button" @click="$emit('close')">Đóng</button>
      </form>
    </div>
  </div>
</template>

<script>
import axios from "axios";

export default {
  props: {
    productId: { type: String, required: true },
    orderId: { type: String, required: false },
    existingReview: Object,
  },
  data() {
    return {
      rating: "",
      comment: "",
    };
  },
  mounted() {
    if (this.existingReview) {
      this.rating = this.existingReview.rating;
      this.comment = this.existingReview.comment;
    }
  },
  methods: {
    async handleSubmit() {
      const token = localStorage.getItem("token");

      const payload = {
        rating: this.rating,
        comment: this.comment,
      };

      try {
        let response;

        if (this.existingReview) {
          response = await axios.put(
            `http://localhost:5000/api/reviews/${this.existingReview._id}`,
            payload,
            { headers: { Authorization: `Bearer ${token}` } }
          );
        } else {
          response = await axios.post(
            "http://localhost:5000/api/reviews",
            {
              productId: this.productId,
              orderId: this.orderId || null,
              ...payload,
            },
            { headers: { Authorization: `Bearer ${token}` } }
          );
        }

        alert("Đánh giá đã được gửi thành công!");
        this.$emit("review-submitted");
        this.$emit("close");
      } catch (err) {
        console.error(
          "Lỗi khi gửi đánh giá:",
          err.response?.data || err.message
        );
        alert("Gửi đánh giá thất bại. Vui lòng thử lại.");
      }
    },
  },
};
</script>

<style scoped>
.modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
}
.modal-content {
  background: #fff;
  max-width: 400px;
  margin: 10% auto;
  padding: 20px;
  border-radius: 8px;
}
textarea {
  width: 100%;
  min-height: 80px;
  margin-top: 5px;
}
button {
  margin-top: 10px;
  margin-right: 10px;
}
</style>
