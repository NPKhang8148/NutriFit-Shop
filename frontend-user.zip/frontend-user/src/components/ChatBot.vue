<template>
  <div class="chat-container">
    <div class="chat-box" ref="chatBox">
      <div
        v-for="(msg, index) in messages"
        :key="index"
        :class="msg.role"
      >
        <strong>{{ msg.role === 'user' ? 'Bạn' : 'AI' }}:</strong>
        {{ msg.content }}
      </div>
    </div>
    <form @submit.prevent="sendMessage" class="chat-form">
      <input v-model="newMessage" placeholder="Nhập câu hỏi..." />
      <button type="submit">Gửi</button>
    </form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      newMessage: '',
      messages: [],
    };
  },
  methods: {
    async sendMessage() {
      const message = this.newMessage.trim();
      if (!message) return;

      this.messages.push({ role: 'user', content: message });

      try {
        const res = await fetch('http://localhost:5000/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ message }),
        });

        const data = await res.json();

        if (data.reply) {
          this.messages.push({ role: 'assistant', content: data.reply });
        } else {
          this.messages.push({ role: 'assistant', content: 'Không có phản hồi từ AI.' });
        }
      } catch (err) {
        console.error(err);
        this.messages.push({ role: 'assistant', content: 'Lỗi máy chủ!' });
      } finally {
        this.newMessage = '';
        this.$nextTick(() => {
          const chatBox = this.$refs.chatBox;
          chatBox.scrollTop = chatBox.scrollHeight;
        });
      }
    },
  },
};
</script>

<style scoped>
.chat-container {
  max-width: 600px;
  margin: auto;
  border: 1px solid #ddd;
  padding: 1rem;
  border-radius: 10px;
  background: #f9f9f9;
}
.chat-box {
  height: 300px;
  overflow-y: auto;
  margin-bottom: 1rem;
  padding: 0.5rem;
  background: #fff;
  border: 1px solid #ccc;
}
.user {
  text-align: right;
  color: #007bff;
  margin: 5px 0;
}
.assistant {
  text-align: left;
  color: #28a745;
  margin: 5px 0;
}
.chat-form {
  display: flex;
  gap: 0.5rem;
}
input {
  flex: 1;
  padding: 0.5rem;
  border-radius: 5px;
  border: 1px solid #ccc;
}
button {
  padding: 0.5rem 1rem;
  border: none;
  background: #007bff;
  color: white;
  border-radius: 5px;
  cursor: pointer;
}
button:hover {
  background: #0056b3;
}
</style>
