<template>
  <div class="chat-widget">
    <div class="chat-toggle" @click="toggleChat">{{ showChat ? '✖' : '💬' }}</div>
    <div v-if="showChat" class="chat-box">
      <div class="chat-messages">
        <div
          v-for="(msg, index) in messages"
          :key="index"
          :class="['message', msg.role]"
        >
          <strong>{{ msg.role === 'user' ? 'Bạn' : 'Bot' }}:</strong>
          <span>{{ msg.content }}</span>
        </div>
      </div>
      <div class="chat-input">
        <input
          type="text"
          v-model="newMessage"
          @keyup.enter="sendMessage"
          placeholder="Nhập câu hỏi..."
        />
        <button @click="sendMessage">Gửi</button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      showChat: false,
      newMessage: "",
      messages: [],
    };
  },
  methods: {
    toggleChat() {
      this.showChat = !this.showChat;
    },
    async sendMessage() {
      if (!this.newMessage.trim()) return;

      const userMsg = { role: "user", content: this.newMessage };
      this.messages.push(userMsg);

      try {
        const res = await fetch("http://localhost:5000/api/chat", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            messages: [...this.messages],
          }),
        });

        const data = await res.json();
        if (data && data.message) {
          this.messages.push({ role: "assistant", content: data.message });
        }
      } catch (err) {
        this.messages.push({ role: "assistant", content: "Lỗi khi kết nối máy chủ." });
      }

      this.newMessage = "";
    },
  },
};
</script>

<style scoped>
.chat-widget {
  position: fixed;
  bottom: 20px;
  right: 20px;
  z-index: 9999;
}

.chat-toggle {
  background: #900b9e;
  color: rgb(90, 14, 222);
  padding: 10px 15px;
  border-radius: 50px;
  cursor: pointer;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
}

.chat-box {
  width: 300px;
  max-height: 400px;
  background: rgb(61, 3, 80);
  border: 1px solid #ccc;
  border-radius: 12px;
  display: flex;
  flex-direction: column;
  margin-top: 10px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
}

.chat-messages {
  flex: 1;
  overflow-y: auto;
  padding: 10px;
}

.message {
  margin-bottom: 10px;
}

.message.user {
  text-align: right;
}

.message.assistant {
  text-align: left;
}

.message span {
  color: #dad0d0;
}

.message strong {
  color: #007bff;
}

.chat-input {
  display: flex;
  border-top: 1px solid #0ca5aa;
}

.chat-input input {
  flex: 1;
  border: none;
  padding: 10px;
  outline: none;
}

.chat-input button {
  padding: 10px;
  border: none;
  background: #007bff;
  color: white;
  cursor: pointer;
}
</style>

