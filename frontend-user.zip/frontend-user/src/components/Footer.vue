<template>
  <footer class="footer">
    <div class="footer-container">
      <div class="footer-section">
        <h3>GIỚI THIỆU CHUNG</h3>
        <p>Giới thiệu về Nutri Fit</p>
        <p>Hướng dẫn đặt hàng</p>
        <p>Hướng dẫn thanh toán</p>
        <p>Quy định chung</p>
        <p>Nội quy cửa hàng</p>
      </div>

      <div class="footer-section">
        <h3>CHÍNH SÁCH CHUNG</h3>
        <p>Chính sách dữ liệu</p>
        <p>Chính sách bảo mật</p>
        <p>Chính sách kinh doanh</p>
        <p>Chính sách vận chuyển</p>
        <p>Chính sách bảo hành</p>
      </div>

      <div class="footer-section">
        <h3>DANH SÁCH CỬA HÀNG</h3>
        <p>
          <i class="fas fa-map-marker-alt"></i> 125 Lê Thanh Nghị, HBT, Hà Nội
          <span class="highlight">• Chỉ đường</span>
        </p>
        <p>
          <i class="fas fa-map-marker-alt"></i> 450 Hoàng Diệu, Hải Châu, Đà
          Nẵng <span class="highlight">• Chỉ đường</span>
        </p>
        <p>
          <i class="fas fa-map-marker-alt"></i> 391 Nguyễn Trãi, P7, Q5, HCM
          <span class="highlight">• Chỉ đường</span>
        </p>
      </div>

      <div class="footer-section">
        <h3>📞 Tư vấn đặt hàng</h3>
        <p class="phone"><i class="fas fa-phone-alt"></i> 091 901 3030</p>
        <p>Theo dõi chúng tôi tại</p>
        <div class="social-icons">
          <a href="#"><i class="fab fa-facebook-f"></i></a>
          <a href="#"><i class="fab fa-youtube"></i></a>
          <a href="#"><i class="fas fa-music"></i></a>
          <a href="#"
            ><img
              src="https://upload.wikimedia.org/wikipedia/commons/9/91/Icon_of_Zalo.svg"
              alt="Zalo"
              height="20"
          /></a>
          <a href="#"><i class="fab fa-instagram"></i></a>
        </div>
      </div>
    </div>
  </footer>
</template>

<script>
export default {
  name: "Footer",
};
</script>

<style scoped>
.footer {
  background-color: #36566a;
  color: white;
  padding: 2rem 1rem 3rem;
  font-family: sans-serif;
  width: 100%;
  box-sizing: border-box;
}

.footer-container {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 2rem;
  max-width: 1200px;
  margin: auto;
}

.footer-section h3 {
  font-weight: bold;
  margin-bottom: 0.75rem;
}

.footer-section p {
  margin: 0.3rem 0;
  font-size: 14px;
}

.footer-section .highlight {
  color: #ffc107;
}

.phone {
  font-size: 18px;
  font-weight: bold;
}

.social-icons a {
  color: white;
  margin-right: 10px;
  font-size: 18px;
}

.social-icons img {
  vertical-align: middle;
  max-width: 100%;
  display: inline-block;
}
</style>

