<template>
  <div class="col-md-4 mb-4">
    <div class="card h-100">
      <div
        class="text-center p-3"
        @click="$emit('click')"
        style="cursor: pointer"
      >
        <img
          :src="product.image"
          :alt="product.name"
          class="card-img-top img-fluid w-100"
          style="height: 180px; object-fit: cover; border-radius: 8px"
        />
      </div>

      <div class="card-body text-center">
        <h5 class="card-title" @click="$emit('click')" style="cursor: pointer">
          {{ product.name }}
        </h5>
        <p class="card-text text-success fw-bold">
          {{ product.price.toLocaleString() }} đ
        </p>

        <!-- Nút thêm vào giỏ hàng -->
        <button
          class="btn btn-sm btn-outline-primary mt-2"
          @click.stop="$emit('add-to-cart', product)"
        >
          🛒 Thêm vào giỏ
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
defineProps({
  product: Object,
});
</script>

<style scoped>
.btn-brown {
  background-color: #8b4513;
  color: white;
}
</style>

<style>
.card:hover {
  transform: translateY(-5px);
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
}
</style>
