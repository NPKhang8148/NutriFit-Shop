<template>
  <header class="bg-green-700 text-white p-4 flex justify-between items-center">
    <!-- <RouterLink to="/" class="text-2xl font-bold">Nutri Fit</RouterLink> -->
    <nav class="space-x-4">
      <template v-if="authStore.user">
        <span>Chào, {{ authStore.user.name }}</span>
        <!-- <button @click="logout" class="underline">Đăng xuất</button> -->
      </template>
      <template v-else>
        <!-- <RouterLink to="/login">Đăng nhập</RouterLink>
        <RouterLink to="/register">Đăng ký</RouterLink> -->
      </template>
    </nav>
  </header>
</template>

<script setup>
import { useAuthStore } from "../stores/auth";
import { useRouter, RouterLink } from "vue-router";

const authStore = useAuthStore();
const router = useRouter();

const logout = () => {
  authStore.logout();
  router.push("/");
};
</script>
