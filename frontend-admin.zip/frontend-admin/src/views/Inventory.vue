<template>
  <div class="kho-container">
    <div class="container mt-4">
    <h2 class="text-center text-success fw-bold pb-3">QUẢN LÍ KHO</h2>
    <div class="row justify-content-center">
      
      <!-- Bảng sản phẩm sắp hết hàng -->
      <div class="col-md-6">
        <h4 class="text-center" style="color: #E04338">Sản phẩm sắp hết hàng</h4>
        <table v-if="lowStockProducts.length" class="table table-bordered shadow rounded">
          <thead>
            <tr>
              <th>#</th>
              <th>Tên sản phẩm</th>
              <th>Số lượng</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(product, index) in lowStockProducts" :key="product._id">
              <td>{{ index + 1 }}</td>
              <td>{{ product.name }}</td>
              <td class="text-danger fw-bold">{{ product.stock }}</td>
            </tr>
          </tbody>
        </table>
        <p v-else class="text-center text-muted">Không có sản phẩm sắp hết hàng.</p>
      </div>
    </div>
  </div>
  </div>
</template>

<script>
import axios from "axios";
import { Modal } from "bootstrap";

export default {
  data() {
    return {
      products: [],
      lowStockProducts: [],
      selectedProduct: null,
      modalInstance: null,
    };
  },
  mounted() {
    this.fetchProducts();
    this.fetchLowStockProducts();
  },
  methods: {
    async fetchProducts() {
      try {
        const token = localStorage.getItem("adminToken");
        const res = await axios.get("http://localhost:5000/api/admin/inventory", {
          headers: { Authorization: `Bearer ${token}` },
        });
        this.products = res.data || [];
      } catch (error) {
        console.error("Lỗi tải danh sách sản phẩm", error);
      }
    },
    async fetchLowStockProducts() {
      try {
        const token = localStorage.getItem("adminToken");
        const res = await axios.get("http://localhost:5000/api/admin/inventory/low-stock", {
          headers: { Authorization: `Bearer ${token}` },
        });
        console.log("Dữ liệu sắp hết hàng:", res.data);
        this.lowStockProducts = res.data || [];
      } catch (error) {
        console.error("Lỗi tải sản phẩm sắp hết hàng", error);
      }
    },
    openModal(product) {
      this.selectedProduct = { ...product, newQuantity: product.quantity };
      this.$nextTick(() => {
        if (!this.modalInstance) {
          this.modalInstance = new Modal(this.$refs.updateStockModal);
        }
        this.modalInstance.show();
      });
    },
    async updateStock() {
  try {
    const token = localStorage.getItem("adminToken");
    console.log("Gửi yêu cầu cập nhật:", {
      id: this.selectedProduct._id,
      quantity: this.selectedProduct.newQuantity,
    });

    await axios.put(
      `http://localhost:5000/api/admin/inventory/${this.selectedProduct._id}`,
      { quantity: this.selectedProduct.newQuantity },
      { headers: { Authorization: `Bearer ${token}` } }
    );

    this.fetchProducts();
    this.modalInstance.hide();
  } catch (error) {
    console.error("Lỗi cập nhật số lượng:", error.response?.data || error);
  }
},

  },
};
</script>

<style scoped>
.kho-container {
  background: url('@/assets/bggym7.jpg') no-repeat center center/cover;
  height: 100vh;
  width: 100vw; 
  overflow: hidden;
}
</style>