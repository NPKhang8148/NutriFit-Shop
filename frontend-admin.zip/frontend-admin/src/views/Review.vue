<template>

  <div class="container mt-4">
    <h2 class="text-center fw-bold pb-3" style="color: #E04338;">QUẢN LÝ ĐÁNH GIÁ</h2>
    <table class="table table-bordered table-hover">
      <thead>
        <tr>
          <th>Người dùng</th>
          <th>Sản phẩm</th>
          <th>Số sao</th>
          <th>Bình luận</th>
          <th>Ngày</th>
          <th>Hành động</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="review in reviews" :key="review._id">
          <td>{{ review.userId?.name }}</td>
          <td>{{ review.productId?.name }}</td>
          <td>{{ review.rating }}</td>
          <td>{{ review.comment }}</td>
          <td>{{ new Date(review.createdAt).toLocaleDateString() }}</td>
          <td>
            <button class="btn btn-danger btn-sm" @click="deleteReview(review._id)">Xóa</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>

</template>

<script setup>
import { ref, onMounted } from 'vue';
import axios from 'axios';
//import AdminLayout from '../components/AdminLayout.vue'

const reviews = ref([]);

const fetchReviews = async () => {
    const token = localStorage.getItem('adminToken')
    const res = await axios.get('http://localhost:5000/api/admin/reviews/all', {
      headers: { Authorization: `Bearer ${token}` }
    })
  reviews.value = res.data;
};

const deleteReview = async (id) => {
  const confirmDelete = confirm('Bạn có chắc muốn xóa đánh giá này?');
  if (!confirmDelete) return;

  const token = localStorage.getItem('adminToken'); 
  try {
    await axios.delete(`http://localhost:5000/api/admin/reviews/delete/${id}`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    reviews.value = reviews.value.filter(r => r._id !== id);
    alert('Xóa đánh giá thành công!');
  } catch (err) {
    console.error('Lỗi khi xóa đánh giá:', err);
    alert('Không thể xóa đánh giá.');
  }
};

onMounted(() => {
  fetchReviews();
});

</script>
