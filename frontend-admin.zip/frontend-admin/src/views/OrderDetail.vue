<template>
    <div class="container mt-4">
      <h2 class="text-center text-info mb-4">Chi tiết đơn hàng</h2>
  
      <div v-if="order">
        <div class="mb-3">
          <strong>Người đặt:</strong> {{ order.user?.name }} ({{ order.user?.email }})
        </div>
        <div class="mb-3">
          <strong>Địa chỉ nhận hàng:</strong> {{ order.shippingAddress }}
        </div>
        <div class="mb-3">
          <strong>Trạng thái:</strong>
          <span :class="statusClass(order.status)">{{ order.status }}</span>
        </div>
        <div class="mb-3">
          <strong>Ngày đặt:</strong> {{ formatDate(order.createdAt) }}
        </div>
        <div class="mb-3">
          <strong>Tổng tiền:</strong> {{ formatCurrency(order.totalPrice) }}
        </div>
  
        <h5 class="mt-4">Danh sách sản phẩm:</h5>
        <table class="table table-bordered table-hover">
          <thead>
            <tr>
              <th>#</th>
              <th>Tên sản phẩm</th>
              <th>Số lượng</th>
              <th>Giá</th>
              <th>Thành tiền</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(item, index) in order.orderItems" :key="index">
              <td>{{ index + 1 }}</td>
              <td>{{ item?.product?.name || 'Không xác định' }}</td>
              <td>{{ item.quantity }}</td>
              <td>{{ formatCurrency(item.price) }}</td>
              <td>{{ formatCurrency(item.price * item.quantity) }}</td>
            </tr>
          </tbody>
        </table>
      </div>
  
      <div v-else class="text-center text-muted">Đang tải dữ liệu...</div>
    </div>
  </template>
  
  <script setup>
  import { onMounted, ref } from 'vue'
  import { useRoute } from 'vue-router'
  import axios from 'axios'
  
  const route = useRoute()
  const order = ref(null)
  
  const fetchOrderDetail = async () => {
    try {
      const token = localStorage.getItem('adminToken')
      const res = await axios.get(`http://localhost:5000/api/admin/orders/${route.params.id}`, {
        headers: { Authorization: `Bearer ${token}` }
      })
      order.value = res.data
    } catch (err) {
      alert('Lỗi khi tải chi tiết đơn hàng')
      console.error('Chi tiết lỗi:', err.response?.data || err.message)
    }
  }
  
  const statusClass = (status) => {
    switch (status) {
      case 'Chờ xác nhận':
        return 'text-warning'
      case 'Đã xác nhận':
        return 'text-primary'
      case 'Đã giao hàng':
        return 'text-success'
      case 'Đã hủy':
        return 'text-danger'
      default:
        return ''
    }
  }
  
  const formatCurrency = (val) => {
    if (!val && val !== 0) return '0 đ'
    return Number(val).toLocaleString('vi-VN') + ' đ'
  }
  
  const formatDate = (date) => {
    return new Date(date).toLocaleString('vi-VN')
  }
  
  onMounted(fetchOrderDetail)
  </script>
  
  <style scoped>
  .container {
    max-width: 800px;
  }
  </style>
  