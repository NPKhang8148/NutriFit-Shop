<template>
  <div class="layout-wrapper">
    <!-- Sidebar -->
    <div class="sidebar">
      <div class="logo">QUẢN LÝ</div>
      <el-menu
        class="el-menu-vertical"
        :default-active="selectedKey"
        @select="onMenuClick"
        background-color="#001529"
        text-color="#fff"
        active-text-color="#409EFF"
        router
      >
        <el-menu-item index="category">Quản lý danh mục</el-menu-item>
        <el-menu-item index="product">Quản lý sản phẩm</el-menu-item>
        <el-menu-item index="order">Quản lý đơn hàng</el-menu-item>
        <el-menu-item index="user">Quản lý người dùng</el-menu-item>
        <el-menu-item index="inventory">Quản lý kho hàng</el-menu-item>
        <el-menu-item index="coupon">Mã giảm giá</el-menu-item>
        <el-menu-item index="revenue">Thống kê doanh thu</el-menu-item>
        <el-menu-item index="review">Quản lý đánh giá</el-menu-item>
      </el-menu>
    </div>

    <!-- Content -->
    <div class="main-content">
      <div class="header">
        <h2>{{ currentPageTitle }}</h2>
      </div>
      <div class="content">
        <router-view />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import { useRoute, useRouter } from "vue-router";

const currentPageTitle = ref("Admin Page");
const selectedKey = ref("category");
const route = useRoute();
const router = useRouter();

const getPageTitle = (key) => {
  const titles = {
    category: "Quản lý danh mục",
    product: "Quản lý sản phẩm",
    order: "Quản lý đơn hàng",
    user: "Quản lý người dùng",
    inventory: "Quản lý kho hàng",
    coupon: "Mã giảm giá",
    revenue: "Thống kê doanh thu",
    review: "Quản lý đánh giá",
  };
  return titles[key] || "Trang Admin";
};

const onMenuClick = (key) => {
  selectedKey.value = key;
  currentPageTitle.value = getPageTitle(key);
  router.push(`/admin/${key}`);
};

onMounted(() => {
  const currentRoute = route.path.split("/").pop();
  selectedKey.value = currentRoute;
  currentPageTitle.value = getPageTitle(currentRoute);
});
</script>

<style scoped>
.layout-wrapper {
  background: url("@/assets/bggym.jpg") no-repeat center center/cover;
  height: 100vh;
  width: 100vw;
  overflow: hidden;
  width: 100%;
}

.sidebar {
  width: 260px;
  background-color: #001529;
  color: white;
  display: flex;
  flex-direction: column;
  height: 100vh;
}

.logo {
  font-weight: bold;
  font-size: 20px;
  text-align: center;
  padding: 16px;
  color: white;
  background-color: #001529;
  border-bottom: 1px solid #ccc;
}

.main-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  background: white;
}

.header {
  padding: 16px 24px;
  border-bottom: 1px solid #eee;
  background-color: #fff;
}

.content {
  padding: 24px;
  flex: 1;
  background: #fff;
}
</style>
