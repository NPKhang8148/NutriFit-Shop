<!-- <template>
  <div class="mg-container">
    <div class="container mt-5">
      <h2 class="mb-4" style="color: white">Quản lý người dùng</h2>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>ID</th>
            <th>Họ tên</th>
            <th>Email</th>
            <th>Vai trò</th>
            <th>Hành động</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="user in users" :key="user._id">
            <td>{{ user._id }}</td>
            <td>{{ user.name }}</td>
            <td>{{ user.email }}</td>
            <td>{{ user.role }}</td>
            <td>
              <button
                class="btn btn-danger btn-sm"
                @click="deleteUser(user._id)"
              >
                Xóa
              </button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import axios from "axios";

const users = ref([]);

const fetchUsers = async () => {
  try {
    const token = localStorage.getItem("adminToken");

    const res = await axios.get("http://localhost:5000/api/admin/users", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    users.value = res.data;
  } catch (err) {
    console.error("Lỗi khi lấy danh sách user:", err);
  }
};

const deleteUser = async (id) => {
  if (confirm("Bạn có chắc muốn xóa người dùng này?")) {
    try {
      const token = localStorage.getItem("adminToken");

      await axios.delete(`http://localhost:5000/api/admin/users/${id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      users.value = users.value.filter((u) => u._id !== id);
    } catch (err) {
      console.error("Xóa thất bại:", err);
    }
  }
};

onMounted(fetchUsers);
</script>

<style scoped>
.mg-container {
  background: url("@/assets/bggym3.jpg") no-repeat center center/cover;
  height: 100vh;
  width: 100vw;
  overflow: hidden;
}
</style> -->


<template>
  <div class="usermanage-container">
    <div class="mg-container py-4">
      <div class="container-xl">
        <h2 class="text-center fw-bold pb-3" style="color: #E04338">QUẢN LÝ NGƯỜI DÙNG</h2>
         <!-- ô tìm và lọc  -->
        <div class="row mb-3">
          <div class="col-md-4">
            <input
              v-model="searchUser"
              type="text"
              class="form-control"
              placeholder="Tìm theo tên người dùng..."
            />
          </div>
          <div class="col-md-4">
            <select v-model="sortOption" class="form-select">
              <option value="createdDesc">Mới nhất</option>
              <option value="createdAsc">Cũ nhất</option>
              <option value="nameAZ">Tên A-Z</option>
              <option value="nameZA">Tên Z-A</option>
            </select>
          </div>
        </div>

        <table class="table table-bordered table-hover">
          <thead class="table-light text-center align-middle">
            <tr>
              <th style="width: 5%">STT</th>
              <th style="width: 15%">Họ tên</th>
              <th style="width: 15%">Email</th>
              <th style="width: 13%">Ngày tạo</th>
              <th style="width: 6%">Giới tính</th>
              <th style="width: 11%">SĐT</th>
              <th style="width: 20%">Địa chỉ</th>
              <th style="width: 15%">Hành động</th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="(user, index) in filteredUsers"
              :key="user._id"
              :class="{ 'row-muted td': user.isBanned }"
              class="align-middle"
            >
              <td class="text-center">{{ index + 1 }}</td>
              <td>{{ user.name }}</td>
              <td>{{ user.email }}</td>
              <td>{{ formatDate(user.createdAt) }}</td>
              <td class="text-center">{{ user.gender || '—' }}</td>
              <td>{{ user.phone || '—' }}</td>
              <td>{{ user.address || '—' }}</td>
              <td class="text-center">
                <button
                  class="btn btn-warning btn-sm me-2"
                  @click="toggleBan(user)"
                >
                  {{ user.isBanned ? 'Mở khóa' : 'Khóa' }}
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

  
<script setup>
  import { ref, onMounted } from 'vue'
  import axios from 'axios'
  //import AdminLayout from '../components/AdminLayout.vue'
  import {computed } from 'vue'

const users = ref([])
const searchUser = ref("")
const sortOption = ref("createdDesc") // mặc định: mới nhất

const filteredUsers = computed(() => {
  let result = [...users.value]

  // Tìm kiếm theo tên
  if (searchUser.value) {
    result = result.filter(u =>
      u.name?.toLowerCase().includes(searchUser.value.toLowerCase())
    )
  }

  // Sắp xếp
  if (sortOption.value === "createdAsc") {
    result.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt))
  } else if (sortOption.value === "createdDesc") {
    result.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
  } else if (sortOption.value === "nameAZ") {
    result.sort((a, b) => a.name.localeCompare(b.name))
  } else if (sortOption.value === "nameZA") {
    result.sort((a, b) => b.name.localeCompare(a.name))
  }

  return result
})
  
const formatDate = (dateStr) => {
  const d = new Date(dateStr)
  return d.toLocaleDateString("vi-VN")
}
  
  const fetchUsers = async () => {
  try {
    const token = localStorage.getItem('adminToken')
    const res = await axios.get('http://localhost:5000/api/users', {
      headers: {
        Authorization: `Bearer ${token}`
      }
    })
    console.log('Dữ liệu users nhận được:', res.data)
    users.value = res.data
  } catch (err) {
    console.error('Lỗi khi lấy danh sách user:', err)
  }
}

  
  const deleteUser = async (id) => {
  if (confirm('Bạn có chắc muốn xóa người dùng này?')) {
    try {
      const token = localStorage.getItem('adminToken')
      await axios.delete(`http://localhost:5000/api/admin/users/${id}`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      })
      users.value = users.value.filter(u => u._id !== id)
    } catch (err) {
      console.error('Xóa thất bại:', err)
    }
  }
}
const toggleBan = async (user) => {
  const action = user.isBanned ? 'mở khóa' : 'khóa'
  if (confirm(`Bạn có chắc muốn ${action} tài khoản của ${user.name}?`)) {
    try {
      const token = localStorage.getItem('adminToken')
      const res = await axios.put(
        `http://localhost:5000/api/admin/users/${user._id}/toggle-ban`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      )

      user.isBanned = !user.isBanned
      alert(res.data.message)
    } catch (err) {
      console.error('Lỗi khi khóa/mở khóa tài khoản:', err)
      alert('Thao tác thất bại!')
    }
  }
}


  onMounted(fetchUsers)
</script>

<style scoped>
/* .mg-container {
  background: url('@/assets/bg2.jpg') no-repeat center center/cover;
  height: 100vh;
  width: 100vw; 
  overflow: hidden;
} */

.row-muted td {
  color: #b2b0b0 !important;
}
.usermanage-container {
  background: url('@/assets/bggym3.jpg') no-repeat center center/cover;
  height: 100vh;
  width: 100vw; 
  overflow: hidden;
}
</style>

  