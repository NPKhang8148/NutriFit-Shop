<template>
  
    <div class="container">
      <h2 class="text-center fw-bold mb-4" style="color: #E04338;">BÁO CÁO DOANH THU</h2>

      <div class="row text-center mb-4">
        <div class="col-md-3 mb-3" v-for="item in summaryStats" :key="item.label">
          <div class="card shadow-sm p-3">
            <div class="fw-bold fs-5" style="color: #E04338;">{{ item.label }}</div>
            <div class="fs-4">{{ item.value }}</div>
          </div>
        </div>
      </div>

      <h4 class="mt-3 mb-3" style="color: #E04338;">Top khách hàng chi tiêu nhiều nhất</h4>
      <table class="table table-bordered table-hover">
        <thead class="table-light">
          <tr>
            <th>Họ tên</th>
            <th>Email</th>
            <th>Tổng chi tiêu</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="customer in report.topCustomers" :key="customer._id">
            <td>{{ customer.user.name }}</td>
            <td>{{ customer.user.email }}</td>
            <td>{{ formatPrice(customer.totalSpent) }}</td>
          </tr>
        </tbody>
      </table>

      <h4 class="mt-5 mb-3" style="color: #E04338;">Top sản phẩm bán chạy</h4>
      <table class="table table-bordered table-hover">
        <thead class="table-light">
          <tr>
            <th>Tên sản phẩm</th>
            <th>Số lượng đã bán</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="product in report.bestSellingProducts" :key="product._id">
            <td>{{ product.product.name }}</td>
            <td>{{ product.totalSold }}</td>
          </tr>
        </tbody>
      </table>
    </div>
 
</template>

<script setup>
import { onMounted, ref } from 'vue'
import axios from 'axios'
//import AdminLayout from '../components/AdminLayout.vue'

const report = ref({})
const summaryStats = ref([])

const formatPrice = (val) =>
  new Intl.NumberFormat('vi-VN').format(val || 0) + '₫'

const fetchReport = async () => {
  try {
    const token = localStorage.getItem('adminToken')
    const res = await axios.get('http://localhost:5000/api/admin/stats/report', {
      headers: { Authorization: `Bearer ${token}` }
    })

    report.value = res.data

    summaryStats.value = [
      { label: 'Tổng doanh thu', value: formatPrice(res.data.totalRevenue) },
      { label: 'Đơn hoàn thành', value: res.data.completedOrders },
      { label: 'Sản phẩm đã bán', value: res.data.totalProductsSold },
      { label: 'Đơn bị hủy', value: res.data.canceledOrders }
    ]
  } catch (err) {
    alert('Không thể tải báo cáo doanh thu.')
    console.error('Lỗi khi gọi API doanh thu:', err)
  }
}

onMounted(fetchReport)
</script>
