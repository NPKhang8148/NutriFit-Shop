<template>
  <div class="mg-container">
    <div class="container mt-5">
      <h2 class="text-center text-success fw-bold pb-3">QUẢN LÝ SẢN PHẨM</h2>

      <!-- Bảng danh sách sản phẩm -->
      <table class="table table-bordered mt-3">
        <thead class="table-success">
          <tr>
            <th>STT</th>
            <th>Tên</th>
            <th>Giá (VNĐ)</th>
            <th>Mô tả</th>
            <th>Ảnh</th>
            <th>Danh mục</th>
            <th>Số lượng</th>
            <th>Hành động</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(product, index) in products" :key="product._id">
            <td>{{ index + 1 }}</td>
            <td>{{ product.name }}</td>
            <td>{{ product.price }}</td>
            <td>{{ product.description }}</td>
            <td><img :src="product.image" alt="Ảnh sản phẩm" width="150" /></td>
            <td>
              {{ product.category ? product.category.name : "Không xác định" }}
            </td>
            <td>{{ product.stock }}</td>
            <td>
              <button
                class="btn btn-primary btn-sm me-2"
                @click="editProduct(product)"
              >
                Sửa
              </button>
              <button
                class="btn btn-danger btn-sm"
                @click="deleteProduct(product._id)"
              >
                Xóa
              </button>
            </td>
          </tr>
        </tbody>
      </table>

      <!-- Form thêm/sửa sản phẩm -->
      <div class="card p-3 mt-4">
        <h5>{{ isEditing ? "Chỉnh sửa sản phẩm" : "Thêm sản phẩm" }}</h5>
        <input
          type="text"
          class="form-control mb-2"
          v-model="productName"
          placeholder="Tên sản phẩm"
          required
        />
        <input
          type="number"
          class="form-control mb-2"
          v-model="productPrice"
          placeholder="Giá sản phẩm"
          required
        />
        <textarea
          class="form-control mb-2"
          v-model="productDescription"
          placeholder="Mô tả sản phẩm"
        ></textarea>
        <!-- Thêm ảnh -->
        <label>Chọn ảnh sản phẩm:</label>
        <input type="file" class="form-control mb-2" @change="uploadImage" />

        <!-- Hiển thị ảnh đã tải lên -->
        <div v-if="productImage">
          <img :src="productImage" alt="Ảnh sản phẩm" width="200" />
        </div>

        <select
          class="form-control mb-2 bg-secondary text-white"
          v-model="productCategory"
        >
          <option value="" disabled>Chọn danh mục</option>
          <option
            v-for="category in categories"
            :key="category._id"
            :value="category._id"
          >
            {{ category.name }}
          </option>
        </select>

        <input
          type="number"
          class="form-control mb-2"
          v-model="productStock"
          placeholder="Số lượng"
          required
        />
        <div class="d-flex justify-content-center mt-2">
          <button
            class="btn btn-success w-30 mx-1"
            @click="isEditing ? updateProduct() : addProduct()"
          >
            {{ isEditing ? "Cập nhật" : "Thêm" }}
          </button>
          <button
            v-if="isEditing"
            class="btn btn-secondary w-30 mx-1"
            @click="cancelEdit"
          >
            Hủy
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import axios from "axios";

// Danh sách sản phẩm và danh mục
const products = ref([]);
const categories = ref([]);

// Biến lưu thông tin sản phẩm nhập vào form
const productName = ref("");
const productPrice = ref("");
const productDescription = ref("");
const productImage = ref("");
const productCategory = ref("");
const productStock = ref("");
const isEditing = ref(false);
const editingProductId = ref(null);

const uploadImage = async (event) => {
  const file = event.target.files[0];
  if (!file) return;

  const formData = new FormData();
  formData.append("image", file);

  try {
    const response = await axios.post(
      "http://localhost:5000/api/admin/upload",
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${localStorage.getItem("adminToken")}`,
        },
      }
    );

    productImage.value = `http://localhost:5000${response.data.imageUrl}`;
  } catch (error) {
    console.error("Lỗi tải ảnh:", error);
  }
};

// Lấy danh sách sản phẩm
const fetchProducts = async () => {
  try {
    const response = await axios.get(
      "http://localhost:5000/api/admin/products",
      {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("adminToken")}`,
        },
      }
    );

    console.log("Danh sách sản phẩm:", response.data); // Debug
    products.value = response.data.products; // Đúng key dữ liệu từ backend
  } catch (error) {
    console.error("Lỗi khi lấy sản phẩm:", error);
  }
};

// Lấy danh sách danh mục
const fetchCategories = async () => {
  try {
    const response = await axios.get(
      "http://localhost:5000/api/admin/categories",
      {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("adminToken")}`,
        },
      }
    );
    categories.value = response.data;
  } catch (error) {
    console.error("Lỗi khi lấy danh mục:", error);
  }
};

// Thêm sản phẩm
const addProduct = async () => {
  if (
    !productName.value ||
    !productPrice.value ||
    !productCategory.value ||
    !productStock.value
  ) {
    alert("Vui lòng nhập đầy đủ thông tin sản phẩm.");
    return;
  }

  try {
    const response = await axios.post(
      "http://localhost:5000/api/admin/products",
      {
        name: productName.value,
        price: productPrice.value,
        description: productDescription.value,
        image: productImage.value,
        category: productCategory.value,
        stock: productStock.value,
      },
      {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("adminToken")}`,
        },
      }
    );

    products.value.push(response.data.product);
    alert("Thêm sản phẩm thành công!");

    // Reset form
    productName.value = "";
    productPrice.value = "";
    productDescription.value = "";
    productImage.value = "";
    productCategory.value = "";
    productStock.value = "";
  } catch (error) {
    console.error("Lỗi khi thêm sản phẩm:", error);
  }
};

// Chọn sản phẩm để chỉnh sửa
const editProduct = (product) => {
  isEditing.value = true;
  editingProductId.value = product._id;
  productName.value = product.name;
  productPrice.value = product.price;
  productDescription.value = product.description;
  productImage.value = product.image;
  productCategory.value = product.category?._id;
  productStock.value = product.stock;
};

// Cập nhật sản phẩm
const updateProduct = async () => {
  try {
    const response = await axios.put(
      `http://localhost:5000/api/admin/products/${editingProductId.value}`,
      {
        name: productName.value,
        price: productPrice.value,
        description: productDescription.value,
        image: productImage.value,
        category: productCategory.value,
        stock: productStock.value,
      },
      {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("adminToken")}`,
        },
      }
    );

    // Cập nhật danh sách sản phẩm
    const index = products.value.findIndex(
      (p) => p._id === editingProductId.value
    );
    if (index !== -1) {
      products.value[index] = response.data.product;
    }

    alert("Cập nhật sản phẩm thành công!");
    cancelEdit();
  } catch (error) {
    console.error("Lỗi khi cập nhật sản phẩm:", error);
  }
};

// Xóa sản phẩm
const deleteProduct = async (id) => {
  if (!confirm("Bạn có chắc chắn muốn xóa sản phẩm này?")) return;

  try {
    await axios.delete(`http://localhost:5000/api/admin/products/${id}`, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("adminToken")}`,
      },
    });

    products.value = products.value.filter((p) => p._id !== id);
    alert("Xóa sản phẩm thành công!");
  } catch (error) {
    console.error("Lỗi khi xóa sản phẩm:", error);
  }
};

// Hủy chỉnh sửa
const cancelEdit = () => {
  isEditing.value = false;
  editingProductId.value = null;
  productName.value = "";
  productPrice.value = "";
  productDescription.value = "";
  productImage.value = "";
  productCategory.value = "";
  productStock.value = "";
};

// Gọi API khi component được tạo
onMounted(() => {
  fetchProducts();
  fetchCategories();
});
</script>

<style scoped>
.mg-container {
  background: url("@/assets/bggym3.jpg") no-repeat center center/cover;
  min-height: 100vh;
  width: 100vw;
  overflow-y: auto;
  padding-bottom: 30px; /* tránh bị dính đáy */
}
</style>
