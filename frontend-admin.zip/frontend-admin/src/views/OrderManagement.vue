<template>
    <div class="container mt-4">
      <h2 class="text-center text-primary mb-4">QUẢN LÝ ĐƠN HÀNG</h2>
  
      <table class="table table-bordered table-hover">
        <thead class="table-light">
          <tr>
            <th>#</th>
            <th>Người đặt</th>
            <th>Email</th>
            <th>Ngày đặt</th>
            <th>Tổng tiền</th>
            <th>Trạng thái</th>
            <th>Thao tác</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(order, index) in orders" :key="order._id">
            <td>{{ index + 1 }}</td>
            <td>{{ order.user?.name }}</td>
            <td>{{ order.user?.email }}</td>
            <td>{{ new Date(order.createdAt).toLocaleString() }}</td>
            <td>{{ order.totalPrice.toLocaleString() }} đ</td>
            <td :class="statusClass(order.status)">{{ order.status }}</td>
            <td class="d-flex gap-2 flex-wrap">
              <router-link :to="`/admin/orders/${order._id}`" class="btn btn-outline-info btn-sm">Chi tiết</router-link>
              <button v-if="order.status === 'Chờ xác nhận'" class="btn btn-success btn-sm" @click="confirmOrder(order._id)">Xác nhận</button>
              <button v-if="order.status === 'Chờ xác nhận'" class="btn btn-warning btn-sm" @click="cancelOrder(order._id)">Hủy</button>
              <button v-if="order.status === 'Đã xác nhận'" class="btn btn-primary btn-sm" @click="markDelivered(order._id)">Giao hàng</button>
              <button class="btn btn-danger btn-sm" @click="deleteOrder(order._id)">Xóa</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </template>
  
  <script setup>
  import { onMounted, ref } from 'vue'
  import axios from 'axios'
  
  const orders = ref([])
  
  const fetchOrders = async () => {
    try {
      const token = localStorage.getItem('adminToken')
      const res = await axios.get('http://localhost:5000/api/admin/orders', {
        headers: { Authorization: `Bearer ${token}` }
      })
      orders.value = res.data
    } catch (err) {
      alert('Không thể tải danh sách đơn hàng.')
      console.error(err)
    }
  }
  
  const confirmOrder = async (id) => {
    if (!confirm('Xác nhận đơn hàng này?')) return
    await handleAction(`confirm`, id)
  }
  
  const cancelOrder = async (id) => {
    if (!confirm('Hủy đơn hàng này?')) return
    await handleAction(`cancel`, id)
  }
  
  const markDelivered = async (id) => {
    if (!confirm('Đánh dấu đã giao hàng?')) return
    await handleAction(`deliver`, id)
  }
  
  const deleteOrder = async (id) => {
    if (!confirm('Bạn có chắc muốn xóa đơn hàng?')) return
    try {
      const token = localStorage.getItem('adminToken')
      await axios.delete(`http://localhost:5000/api/admin/orders/${id}`, {
        headers: { Authorization: `Bearer ${token}` }
      })
      fetchOrders()
    } catch (err) {
      alert('Lỗi khi xóa đơn hàng')
      console.error(err)
    }
  }
  
  const handleAction = async (action, id) => {
    try {
      const token = localStorage.getItem('adminToken')
      await axios.put(`http://localhost:5000/api/admin/orders/${id}/${action}`, {}, {
        headers: { Authorization: `Bearer ${token}` }
      })
      fetchOrders()
    } catch (err) {
      alert(`Thao tác thất bại: ${action}`)
      console.error(err)
    }
  }
  
  const statusClass = (status) => {
    switch (status) {
      case 'Chờ xác nhận':
        return 'text-warning'
      case 'Đã xác nhận':
        return 'text-primary'
      case 'Đã giao hàng':
        return 'text-success'
      case 'Đã hủy':
        return 'text-danger'
      default:
        return ''
    }
  }
  
  onMounted(fetchOrders)
  </script>
  
  <style scoped>
  .container {
    max-width: 1100px;
  }
  </style>
  