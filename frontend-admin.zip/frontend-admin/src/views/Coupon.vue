<template>
  <div class="coupon-container">
    <div class="container mt-4">
      <h2 class="text-center text-success fw-bold pb-3">Quản lý mã giảm giá</h2>
      <button class="btn btn-success mb-3" @click="openModal(null)">Thêm mã giảm giá</button>
  
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>#</th>
            <th>Mã</th>
            <th>Giảm giá</th>
            <th>Loại</th>
            <th>Số lượng</th>
            <th>Hạn sử dụng</th>
            <th>Hành động</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(coupon, index) in coupons" :key="coupon._id">
            <td>{{ index + 1 }}</td>
            <td>{{ coupon.code }}</td>
            <td>{{ coupon.discount }} {{ coupon.discountType === "percentage" ? "%" : "VNĐ" }}</td>
            <td>{{ coupon.discountType === "percentage" ? "Phần trăm" : "Số tiền cố định" }}</td>
            <td>{{ coupon.quantity }}</td>
            <td>{{ new Date(coupon.expiryDate).toLocaleDateString() }}</td>
            <td>
              <button class="btn btn-warning btn-sm me-2" @click="openModal(coupon)">Sửa</button>
              <button class="btn btn-danger btn-sm" @click="deleteCoupon(coupon._id)">Xóa</button>
            </td>
          </tr>
        </tbody>
      </table>
  
      <!-- Modal thêm/sửa mã giảm giá -->
      <div class="modal fade" id="couponModal" tabindex="-1">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">{{ editMode ? "Sửa mã giảm giá" : "Thêm mã giảm giá" }}</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <input v-model="couponData.code" class="form-control mb-2" placeholder="Mã giảm giá" />
  
              <input v-model.number="couponData.discount" class="form-control mb-2" placeholder="Giá trị giảm" type="number" />
  
              <select v-model="couponData.discountType" class="form-control mb-2">
                <option value="percentage">Phần trăm (%)</option>
                <option value="fixed">Số tiền cố định (VNĐ)</option>
              </select>
  
              <input v-model.number="couponData.quantity" class="form-control mb-2" placeholder="Số lượng mã" type="number" />
  
              <input type="date" v-model="couponData.expiryDate" class="form-control mb-2" />
            </div>
            <div class="modal-footer">
              <button class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
              <button class="btn btn-primary" @click="saveCoupon">{{ editMode ? "Cập nhật" : "Thêm" }}</button>
            </div>
          </div>
        </div>
      </div>
  
    </div>
  </div>    
</template>
  
  <script>
  import axios from "axios";
  import { Modal } from "bootstrap";
  
  export default {
    data() {
      return {
        coupons: [],
        couponData: { code: "", discount: "", discountType: "percentage", quantity: "", expiryDate: "" },
        editMode: false,
        modalInstance: null,
      };
    },
    mounted() {
      this.fetchCoupons();
      this.$nextTick(() => {
        this.modalInstance = new Modal(document.getElementById("couponModal"));
      });
    },
    methods: {
      formatDate(date) {
        if (!date) return "";
        return date.split("T")[0]; // Chỉ lấy phần YYYY-MM-DD
      },
  
      async fetchCoupons() {
        try {
          const token = localStorage.getItem("adminToken");
          const res = await axios.get("http://localhost:5000/api/admin/coupons", {
            headers: { Authorization: `Bearer ${token}` },
          });
          this.coupons = res.data;
        } catch (error) {
          console.error("Lỗi tải danh sách mã giảm giá", error);
        }
      },
  
    openModal(coupon) {
        if (coupon) {
            this.couponData = { 
            ...coupon, 
            expiryDate: this.formatDate(coupon.expiryDate) 
            };
            this.editMode = true;
        } else {
            this.couponData = { code: "", discount: "", discountType: "percentage", quantity: "", expiryDate: "" };
            this.editMode = false;
        }
        
        this.$nextTick(() => {
            this.modalInstance.show();
            document.getElementById("couponModal").querySelector("input").focus(); // Focus vào ô nhập mã giảm giá
        });
        },

  
      async saveCoupon() {
        try {
          const token = localStorage.getItem("adminToken");
  
          // Định dạng đúng dữ liệu gửi đi
          const couponData = {
            code: this.couponData.code,
            discount: this.couponData.discount,
            discountType: this.couponData.discountType,
            expiryDate: new Date(this.couponData.expiryDate).toISOString(),
            quantity: this.couponData.quantity,
          };
  
          console.log("Dữ liệu gửi đi:", couponData); // Kiểm tra log
  
          if (this.editMode) {
            await axios.put(`http://localhost:5000/api/admin/coupons/${this.couponData._id}`, couponData, {
              headers: { Authorization: `Bearer ${token}` },
            });
          } else {
            await axios.post("http://localhost:5000/api/admin/coupons", couponData, {
              headers: { Authorization: `Bearer ${token}` },
            });
          }
          this.fetchCoupons();
          this.modalInstance.hide();

          this.$nextTick(() => {
            document.activeElement.blur(); // Xóa focus khỏi modal sau khi đóng
    });

        } catch (error) {
          console.error("Lỗi lưu mã giảm giá", error.response?.data || error.message);
        }
      },
  
      async deleteCoupon(couponId) {
        console.log("Xóa mã giảm giá ID:", couponId);
        try {
          await axios.delete(`http://localhost:5000/api/admin/coupons/${couponId}`, {
            headers: { Authorization: `Bearer ${localStorage.getItem("adminToken")}` },
          });
          alert("Xóa thành công!");
          this.fetchCoupons(); // Load lại danh sách sau khi xóa
        } catch (error) {
          console.error("Lỗi xóa mã giảm giá:", error);
          alert("Không thể xóa mã giảm giá!");
        }
      },
    },
  };
  </script>
  
<style scoped>
  .coupon-container {
    background: url('@/assets/bggym3.jpg') no-repeat center center/cover;
    height: 100vh;
    width: 100vw; 
    overflow: hidden;
  }
</style>