<template>
  <div class="mg-container">
    <div class="container py-4">
      <h2 class="mb-4">📦 Quản lý đơn hàng</h2>

      <div v-if="orders.length > 0">
        <div
          v-for="order in orders"
          :key="order._id"
          class="card mb-3 shadow-sm"
        >
          <div class="card-body">
            <p><strong>Mã đơn:</strong> {{ order._id }}</p>
            <p>
              <strong>Người mua:</strong> {{ order.user?.name }} ({{
                order.user?.email
              }})
            </p>
            <p>
              <strong>Ngày đặt:</strong>
              {{ new Date(order.createdAt).toLocaleString() }}
            </p>
            <p>
              <strong>Tổng tiền:</strong>
              {{ order.totalPrice.toLocaleString() }} đ
            </p>
            <p>
              <strong>Trạng thái:</strong>
              <span :class="statusClass(order.status)">{{ order.status }}</span>
            </p>

            <div class="d-flex gap-2 justify-content-end flex-wrap mt-3">
              <button
                class="btn btn-outline-success btn-sm"
                @click="confirmOrder(order._id)"
                v-if="order.status === 'Chờ xác nhận'"
              >
                ✅ Xác nhận
              </button>

              <button
                class="btn btn-outline-warning btn-sm"
                @click="deliverOrder(order._id)"
                v-if="order.status === 'Đã xác nhận'"
              >
                🚚 Giao hàng
              </button>

              <button
                class="btn btn-outline-danger btn-sm"
                @click="cancelOrder(order._id)"
                v-if="order.status === 'Chờ xác nhận'"
              >
                ❌ Hủy
              </button>

              <button
                class="btn btn-outline-secondary btn-sm"
                @click="deleteOrder(order._id)"
              >
                🗑 Xóa
              </button>
            </div>
          </div>
        </div>
      </div>

      <div v-else>
        <p>Không có đơn hàng nào.</p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import axios from "axios";
import { useAuthStore } from "@/stores/auth";
import Category from "./Category.vue";

const orders = ref([]);
const auth = useAuthStore();

const fetchOrders = async () => {
  try {
    const res = await axios.get("http://localhost:5000/api/admin/orders", {
      headers: {
        Authorization: `Bearer ${auth.token}`,
      },
    });
    orders.value = res.data;
  } catch (error) {
    alert("Không thể tải đơn hàng");
    console.error(error);
  }
};

const confirmOrder = async (id) => {
  if (!confirm("Xác nhận đơn hàng này?")) return;
  try {
    await axios.put(
      `http://localhost:5000/api/admin/orders/${id}/confirm`,
      {},
      {
        headers: { Authorization: `Bearer ${auth.token}` },
      }
    );
    fetchOrders();
  } catch (error) {
    alert("Không thể xác nhận đơn hàng");
  }
};

const cancelOrder = async (id) => {
  if (!confirm("Hủy đơn hàng này?")) return;
  try {
    await axios.put(
      `http://localhost:5000/api/admin/orders/${id}/cancel`,
      {},
      {
        headers: { Authorization: `Bearer ${auth.token}` },
      }
    );
    fetchOrders();
  } catch (error) {
    alert("Không thể hủy đơn hàng");
  }
};

const deliverOrder = async (id) => {
  if (!confirm("Đánh dấu đơn hàng là đã giao?")) return;
  try {
    await axios.put(
      `http://localhost:5000/api/admin/orders/${id}/deliver`,
      {},
      {
        headers: { Authorization: `Bearer ${auth.token}` },
      }
    );
    fetchOrders();
  } catch (error) {
    alert("Không thể cập nhật trạng thái giao hàng");
  }
};

const deleteOrder = async (id) => {
  if (!confirm("Xóa đơn hàng này?")) return;
  try {
    await axios.delete(`http://localhost:5000/api/admin/orders/${id}`, {
      headers: { Authorization: `Bearer ${auth.token}` },
    });
    fetchOrders();
  } catch (error) {
    alert("Không thể xóa đơn hàng");
  }
};

const statusClass = (status) => {
  switch (status) {
    case "Chờ xác nhận":
      return "text-warning";
    case "Đã xác nhận":
      return "text-primary";
    case "Đã giao hàng":
    case "Hoàn thành":
      return "text-success";
    case "Đã hủy":
      return "text-danger";
    default:
      return "";
  }
};

onMounted(() => {
  fetchOrders();
});
</script>

<style scoped>
.mg-container {
  background: url("@/assets/bggym3.jpg") no-repeat center center/cover;
  height: 100vh;
  width: 100vw;
  overflow: hidden;
}
</style>
