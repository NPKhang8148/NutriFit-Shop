<template>
    <div>
      <Bar :data="chartData" :options="chartOptions" />
    </div>
  </template>
  
  <script setup>
  import { Bar } from 'vue-chartjs'
  import {
    Chart as ChartJS,
    Title,
    Tooltip,
    Legend,
    BarElement,
    CategoryScale,
    LinearScale,
  } from 'chart.js'
  import { computed } from 'vue'
  
  ChartJS.register(Title, Tooltip, Legend, BarElement, CategoryScale, LinearScale)
  
  const props = defineProps({
    data: Object,
  })
  
  const chartData = computed(() => ({
    labels: Object.keys(props.data || {}),
    datasets: [
      {
        label: 'Doanh thu theo tháng',
        backgroundColor: '#4caf50',
        data: Object.values(props.data || {}),
      },
    ],
  }))
  
  const chartOptions = {
    responsive: true,
    plugins: {
      legend: { position: 'top' },
      title: { display: true, text: 'Thống kê doanh thu theo tháng' },
    },
  }
  </script>
  