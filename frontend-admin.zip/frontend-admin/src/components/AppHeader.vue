<!-- <template>
  <nav class="navbar navbar-expand-lg navbar-dark bg-success">
    <div class="container">
      <a
        @click="goToHome"
        class="navbar-brand d-flex align-items-center"
        style="cursor: pointer"
      >
        <img
          src="../assets/logonutrifit.jpg"
          alt="NutriFit Logo"
          width="40"
          height="40"
          class="me-2"
        />
        NUTRI FIT
      </a>
      <button
        class="navbar-toggler"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#navbarNav"
      >
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item" v-if="!isAuthenticated">
            <router-link to="/register" class="nav-link">Đăng ký</router-link>
          </li>
          <li class="nav-item" v-if="!isAuthenticated">
            <router-link to="/login" class="nav-link">Đăng nhập</router-link>
          </li>
          <li class="nav-item" v-if="isAuthenticated">
            <button class="btn btn-danger" @click="handleLogout">
              Đăng xuất
            </button>
          </li>
        </ul>
      </div>
    </div>
  </nav>
</template> -->

<!-- <script>
export default {
  data() {
    return {
      isAuthenticated: !!localStorage.getItem("adminToken"),
    };
  },
  methods: {
    goToHome() {
      if (this.isAuthenticated) {
        this.$router.push("/home");
      } else {
        this.$router.push("/");
      }
    },
    handleLogout() {
      localStorage.removeItem("adminToken");
      this.isAuthenticated = false; // Cập nhật trạng thái đăng nhập
      this.$router.push("/");
    },
  },
  watch: {
    $route() {
      this.isAuthenticated = !!localStorage.getItem("adminToken");
    },
  },
};
</script> -->


<template>
  <el-header class="app-header">
    <el-row align="middle" justify="space-between" class="header-content">
      <!-- Logo -->
      <el-col :span="6" class="logo-area" @click="goToHome" style="cursor: pointer;">
        <el-avatar :size="40" :src="logoSrc" class="me-2" />
        <span class="brand-name">NUTRI FIT</span>
      </el-col>

      <!-- Menu -->
      <el-col :span="6" class="menu-area" style="text-align: right;">
        <template v-if="!isAuthenticated">
          <router-link to="/register">
            <el-button type="success" text>Đăng ký</el-button>
          </router-link>
          <router-link to="/login">
            <el-button type="success" text>Đăng nhập</el-button>
          </router-link>
        </template>
        <template v-else>
          <el-button type="danger" @click="handleLogout">Đăng xuất</el-button>
        </template>
      </el-col>
    </el-row>
  </el-header>
</template>

<script>
import logo from "@/assets/logonutrifit.jpg";

export default {
  data() {
    return {
      isAuthenticated: !!localStorage.getItem("adminToken"),
      logoSrc: logo,
    };
  },
  methods: {
    goToHome() {
      this.$router.push(this.isAuthenticated ? "/home" : "/");
    },
    handleLogout() {
      localStorage.removeItem("adminToken");
      this.isAuthenticated = false;
      this.$router.push("/");
    },
  },
  watch: {
    $route() {
      this.isAuthenticated = !!localStorage.getItem("adminToken");
    },
  },
};
</script>

<style scoped>
.app-header {
  background-color: #0cb58a;
  padding: 10px 20px;
  color: white;
}
.brand-name {
  font-size: 20px;
  font-weight: bold;
  margin-left: 10px;
  vertical-align: middle;
}
.el-button {
  margin-left: 10px;
}
</style>

