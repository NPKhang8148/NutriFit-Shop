<template>
  <div class="admin-layout">
    <!-- Sidebar -->
    <aside class="sidebar">
      <h2 class="logo">🏋️‍♂️ NutriFit Admin</h2>
      <nav>
        <router-link to="/admin/dashboard">Tổng quan</router-link>
        <router-link to="/admin/users">Người dùng</router-link>
        <router-link to="/admin/products">Sản phẩm</router-link>
        <router-link to="/admin/categories">Danh mục</router-link>
        <router-link to="/admin/suppliers">Nhà cung cấp</router-link>
        <router-link to="/admin/chatbot">Chatbot AI</router-link>
      </nav>
    </aside>

    <!-- Main Content -->
    <div class="main-content">
      <header class="header">
        <h1>Trang quản trị</h1>
      </header>

      <main class="content">
        <router-view />
      </main>
    </div>
  </div>
</template>

<style scoped>
.admin-layout {
  display: flex;
  min-height: 100vh;
  font-family: Arial, sans-serif;
}

.sidebar {
  width: 220px;
  background-color: #1e293b;
  color: white;
  padding: 20px;
}

.logo {
  font-size: 18px;
  margin-bottom: 1rem;
}

nav a {
  display: block;
  color: white;
  text-decoration: none;
  margin: 8px 0;
  padding: 6px;
  border-radius: 4px;
}

nav a.router-link-active {
  background-color: #3b82f6;
}

.main-content {
  flex: 1;
  background-color: #f1f5f9;
  display: flex;
  flex-direction: column;
}

.header {
  background-color: #e2e8f0;
  padding: 16px;
  border-bottom: 1px solid #cbd5e1;
}

.content {
  flex: 1;
  padding: 20px;
}
</style>
