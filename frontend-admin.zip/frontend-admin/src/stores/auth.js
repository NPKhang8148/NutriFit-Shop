router.beforeEach((to, from, next) => {
  const user = JSON.parse(localStorage.getItem("user"));

  if (to.path.startsWith("/admin") && (!user || user.role !== "admin")) {
    next("/login"); // chặn nếu không phải admin
  } else {
    next();
  }
});
