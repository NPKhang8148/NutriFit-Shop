require("dotenv").config();
const express = require("express");
const cors = require("cors");
const morgan = require("morgan");
const connectDB = require("./config/db");

const app = express();
connectDB();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(morgan("dev"));

// Admin Routes
app.use("/api/admin", require("./routes/adminRoutes"));
app.use("/api/admin/categories", require("./routes/adminCategoryRoutes"));
app.use("/api/admin", require("./routes/adminProductRoutes"));
app.use("/api/admin/orders", require("./routes/adminOrderRoutes"));
app.use("/api/admin/reviews", require("./routes/adminReviewRoutes"));
app.use("/api/admin", require("./routes/adminManageUserRoutes"));
app.use("/api/admin/inventory", require("./routes/adminInventoryRoutes"));
app.use("/api/admin/coupons", require("./routes/adminCouponRoutes"));
//app.use("/api/admin", require("./routes/adminRevenueRoutes"));
app.use("/api/admin/stats", require("./routes/adminStatsRoutes"));

// User Routes
app.use("/api/users", require("./routes/userRoutes"));
app.use("/api/users/orders", require("./routes/userOrderRoutes"));
app.use("/api/users/reviews", require("./routes/userReviewRoutes"));
app.use("/api/cart", require("./routes/cartRoutes"));
app.use("/api/categories", require("./routes/categoryRoutes"));
app.use("/api/users/products", require("./routes/userProductRoutes")); // ✅ chính xác
//app.use("/api/users", require("./routes/userProductRoutes"));

const chatRoutes = require("./routes/chatRoutes");
app.use("/api", chatRoutes);

// Static files
app.use("/uploads", express.static("uploads"));

// Test Route
app.get("/", (req, res) => {
  res.send("Chào mừng đến với Nutri Fit!");
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(` Server đang chạy trên cổng ${PORT}`);
});

// Middleware xử lý lỗi
app.use((err, req, res, next) => {
  console.error("Lỗi không xác định:", err.stack);
  res.status(500).json({ message: "Lỗi máy chủ", error: err.message });
});
