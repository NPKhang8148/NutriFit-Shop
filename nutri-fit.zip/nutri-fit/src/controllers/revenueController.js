const Order = require('../models/Order');

const getRevenueStats = async (req, res) => {
  try {
    const orders = await Order.find({ status: { $ne: "Đã hủy" } });

    let totalRevenue = 0;
    let totalOrders = 0;
    const monthlyRevenue = {}; // { '2025-04': 1200000 }

    orders.forEach(order => {
      totalRevenue += order.totalPrice;
      totalOrders++;

      const month = order.createdAt.toISOString().slice(0, 7); // "2025-04"
      if (!monthlyRevenue[month]) {
        monthlyRevenue[month] = 0;
      }
      monthlyRevenue[month] += order.totalPrice;
    });

    res.json({
      totalRevenue,
      totalOrders,
      monthlyRevenue,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Lỗi server khi thống kê doanh thu' });
  }
};

module.exports = { getRevenueStats };
