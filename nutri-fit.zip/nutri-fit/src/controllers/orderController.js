// const Order = require("../models/Order");
// const Product = require("../models/Product");
// const Coupon = require("../models/Coupon");
// const User = require("../models/User");

// // 1️. User đặt hàng
// const createOrder = async (req, res) => {
//   try {
//     const {
//       orderItems,
//       shippingAddress,
//       paymentMethod,
//       totalPrice,
//       couponCode,
//       phoneNumber,
//     } = req.body;

//     if (!orderItems || orderItems.length === 0) {
//       return res
//         .status(400)
//         .json({ message: "Không có sản phẩm trong đơn hàng!" });
//     }

//     let discountAmount = 0;
//     if (couponCode) {
//       const coupon = await Coupon.findOne({ code: couponCode });
//       if (!coupon) {
//         return res.status(400).json({ message: "Mã giảm giá không hợp lệ!" });
//       }
//       if (new Date(coupon.expiryDate) < new Date()) {
//         return res.status(400).json({ message: "Mã giảm giá đã hết hạn!" });
//       }
//       if (totalPrice < coupon.minOrderValue) {
//         return res.status(400).json({
//           message: `Đơn hàng phải từ ${coupon.minOrderValue} để áp dụng mã giảm giá!`,
//         });
//       }
//       discountAmount = (totalPrice * coupon.discount) / 100;
//       totalPrice -= discountAmount;
//       coupon.quantity -= 1;
//       await coupon.save();
//     }

//     // Kiểm tra số lượng kho
//     for (const item of orderItems) {
//       const product = await Product.findById(item.product);
//       if (!product || product.stock < item.quantity) {
//         return res.status(400).json({
//           message: `Sản phẩm ${
//             product?.name || "không xác định"
//           } không đủ hàng!`,
//         });
//       }
//     }

//     // Giảm số lượng kho
//     for (const item of orderItems) {
//       const product = await Product.findById(item.product);
//       product.stock -= item.quantity;
//       await product.save();
//     }

//     // Tạo đơn hàng
//     const order = new Order({
//       user: req.user._id,
//       orderItems,
//       shippingAddress,
//       phoneNumber,
//       paymentMethod,
//       totalPrice,
//       discountAmount,
//       couponCode,
//       status: "Chờ xác nhận",
//     });

//     await order.save();
//     // Cập nhật địa chỉ và số điện thoại mới vào user
//     await User.findByIdAndUpdate(req.user._id, {
//       phone: phoneNumber,
//       address: shippingAddress,
//     });

//     res.status(201).json({ message: "Đặt hàng thành công!", order });
//   } catch (error) {
//     res.status(500).json({ message: "Lỗi server", error });
//   }
// };

// // 2️. User hủy đơn hàng (chỉ khi đang chờ xác nhận)
// const cancelOrder = async (req, res) => {
//   try {
//     const order = await Order.findById(req.params.id);

//     if (!order) {
//       return res.status(404).json({ message: "Không tìm thấy đơn hàng" });
//     }

//     if (order.status !== "Chờ xác nhận") {
//       return res
//         .status(400)
//         .json({ message: "Chỉ có thể hủy đơn hàng khi đang chờ xác nhận" });
//     }

//     // Hoàn lại số lượng kho
//     for (const item of order.orderItems) {
//       const product = await Product.findById(item.product);
//       product.stock += item.quantity;
//       await product.save();
//     }

//     order.status = "Đã hủy";
//     await order.save();

//     res.json({ message: "Hủy đơn hàng thành công!", order });
//   } catch (error) {
//     res.status(500).json({ message: "Lỗi server", error });
//   }
// };

// // 3️. User xem danh sách đơn hàng của chính mình
// const getUserOrders = async (req, res) => {
//   try {
//     const orders = await Order.find({ user: req.user._id }).sort({
//       createdAt: -1,
//     });
//     res.json(orders);
//   } catch (error) {
//     res.status(500).json({ message: "Lỗi server", error });
//   }
// };

// //Nơi lưu đơn hàng
// const placeOrder = async (req, res) => {
//   try {
//     console.log("Dữ liệu nhận từ frontend:", req.body);
//     console.log("User:", req.user); // nếu dùng middleware

//     const newOrder = new Order({
//       user: req.user.id,
//       orderItems: req.body.orderItems,
//       totalPrice: req.body.totalPrice,
//       shippingAddress: req.body.shippingAddress,
//       phoneNumber: req.body.phoneNumber,
//     });

//     const savedOrder = await newOrder.save();
//     console.log("Đơn hàng đã lưu:", savedOrder);
//     res.status(201).json(savedOrder);
//   } catch (error) {
//     console.error("Lỗi khi đặt hàng:", error);
//     res.status(500).json({ message: "Không thể đặt hàng." });
//   }
// };

// // 4️. Admin xem tất cả đơn hàng
// const getAllOrders = async (req, res) => {
//   try {
//     const orders = await Order.find()
//       .populate("user", "name email")
//       .sort({ createdAt: -1 });
//     res.json(orders);
//   } catch (error) {
//     res.status(500).json({ message: "Lỗi server", error });
//   }
// };

// // 5️. Admin cập nhật trạng thái đơn hàng (VD: Đang giao, Đã giao)
// const updateOrderStatus = async (req, res) => {
//   try {
//     const order = await Order.findById(req.params.id);

//     if (!order) {
//       return res.status(404).json({ message: "Không tìm thấy đơn hàng" });
//     }

//     order.status = req.body.status || order.status;
//     await order.save();

//     res.json({ message: "Cập nhật trạng thái đơn hàng thành công!", order });
//   } catch (error) {
//     res.status(500).json({ message: "Lỗi server", error });
//   }
// };

// module.exports = {
//   createOrder,
//   cancelOrder,
//   placeOrder,
//   getUserOrders,
//   getAllOrders,
//   updateOrderStatus,
// };

const Order = require("../models/Order");
const Product = require("../models/Product");
const Coupon = require("../models/Coupon");
const User = require("../models/User");

// 1️. User đặt hàng
const createOrder = async (req, res) => {
  try {
    const {
      orderItems,
      shippingAddress,
      paymentMethod,
      totalPrice: rawTotalPrice,
      couponCode,
      phoneNumber,
    } = req.body;

    if (!orderItems || orderItems.length === 0) {
      return res
        .status(400)
        .json({ message: "Không có sản phẩm trong đơn hàng!" });
    }

    let discountAmount = 0;
    let totalPrice = rawTotalPrice;

    if (couponCode) {
      const coupon = await Coupon.findOne({ code: couponCode });
      if (!coupon) {
        return res.status(400).json({ message: "Mã giảm giá không hợp lệ!" });
      }
      if (new Date(coupon.expiryDate) < new Date()) {
        return res.status(400).json({ message: "Mã giảm giá đã hết hạn!" });
      }
      if (totalPrice < coupon.minOrderValue) {
        return res.status(400).json({
          message: `Đơn hàng phải từ ${coupon.minOrderValue} để áp dụng mã giảm giá!`,
        });
      }

      discountAmount = (totalPrice * coupon.discount) / 100;
      totalPrice -= discountAmount;

      coupon.quantity -= 1;
      await coupon.save();
    }

    // Kiểm tra số lượng kho
    for (const item of orderItems) {
      const product = await Product.findById(item.product);
      if (!product || product.stock < item.quantity) {
        return res.status(400).json({
          message: `Sản phẩm ${
            product?.name || "không xác định"
          } không đủ hàng!`,
        });
      }
    }

    // Giảm số lượng kho
    for (const item of orderItems) {
      const product = await Product.findById(item.product);
      product.stock -= item.quantity;
      await product.save();
    }

    // Tạo đơn hàng
    const order = new Order({
      user: req.user._id,
      orderItems,
      shippingAddress,
      phoneNumber,
      paymentMethod,
      totalPrice,
      discountAmount,
      couponCode,
      status: "Chờ xác nhận",
    });

    await order.save();

    // Cập nhật thông tin user
    await User.findByIdAndUpdate(req.user._id, {
      phone: phoneNumber,
      address: shippingAddress,
    });

    res.status(201).json({ message: "Đặt hàng thành công!", order });
  } catch (error) {
    console.error("Lỗi khi đặt hàng:", error);
    res.status(500).json({ message: "Lỗi server", error });
  }
};

// 2️. User hủy đơn hàng
const cancelOrder = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);

    if (!order) {
      return res.status(404).json({ message: "Không tìm thấy đơn hàng" });
    }

    if (order.status !== "Chờ xác nhận") {
      return res
        .status(400)
        .json({ message: "Chỉ có thể hủy đơn hàng khi đang chờ xác nhận" });
    }

    // Hoàn lại kho
    for (const item of order.orderItems) {
      const product = await Product.findById(item.product);
      product.stock += item.quantity;
      await product.save();
    }

    order.status = "Đã hủy";
    await order.save();

    res.json({ message: "Hủy đơn hàng thành công!", order });
  } catch (error) {
    console.error("Lỗi khi hủy đơn hàng:", error);
    res.status(500).json({ message: "Lỗi server", error });
  }
};

// 3️. User xem danh sách đơn hàng của mình
const getUserOrders = async (req, res) => {
  try {
    const orders = await Order.find({ user: req.user._id }).sort({
      createdAt: -1,
    });
    res.json(orders);
  } catch (error) {
    res.status(500).json({ message: "Lỗi server", error });
  }
};

// 4️. Admin xem tất cả đơn hàng
const getAllOrders = async (req, res) => {
  try {
    const orders = await Order.find()
      .populate("user", "name email")
      .sort({ createdAt: -1 });
    res.json(orders);
  } catch (error) {
    res.status(500).json({ message: "Lỗi server", error });
  }
};

// 5️. Admin cập nhật trạng thái đơn hàng
const updateOrderStatus = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);

    if (!order) {
      return res.status(404).json({ message: "Không tìm thấy đơn hàng" });
    }

    order.status = req.body.status || order.status;
    await order.save();

    res.json({ message: "Cập nhật trạng thái đơn hàng thành công!", order });
  } catch (error) {
    res.status(500).json({ message: "Lỗi server", error });
  }
};

module.exports = {
  createOrder,
  cancelOrder,
  getUserOrders,
  getAllOrders,
  updateOrderStatus,
};
