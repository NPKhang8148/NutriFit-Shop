// const Order = require("../models/Order");
// const Product = require("../models/Product");
// const User = require("../models/User");

// // Lấy báo cáo thống kê
// const getSalesReport = async (req, res) => {
//   try {
//     // 1️. Tổng doanh thu từ đơn hàng hoàn thành
//     const totalRevenue = await Order.aggregate([
//       { $match: { status: "Hoàn thành" } },
//       { $group: { _id: null, total: { $sum: "$totalPrice" } } },
//     ]);

//     // 2️. Số đơn hàng đã hoàn thành
//     const completedOrders = await Order.countDocuments({
//       status: "Hoàn thành",
//     });

//     // 3️. Số lượng sản phẩm đã bán
//     const totalProductsSold = await Order.aggregate([
//       { $match: { status: "Hoàn thành" } },
//       { $unwind: "$orderItems" },
//       { $group: { _id: null, totalSold: { $sum: "$orderItems.quantity" } } },
//     ]);

//     // 4️. Số đơn hàng bị hủy
//     const canceledOrders = await Order.countDocuments({ status: "Đã hủy" });

//     // 5️. Khách hàng có tổng đơn hàng cao nhất
//     const topCustomers = await Order.aggregate([
//       { $match: { status: "Hoàn thành" } },
//       { $group: { _id: "$user", totalSpent: { $sum: "$totalPrice" } } },
//       { $sort: { totalSpent: -1 } },
//       { $limit: 5 },
//     ]).lookup({
//       from: "users",
//       localField: "_id",
//       foreignField: "_id",
//       as: "user",
//     });

//     // 6️. Sản phẩm bán chạy nhất
//     const bestSellingProducts = await Order.aggregate([
//       { $match: { status: "Hoàn thành" } },
//       { $unwind: "$orderItems" },
//       {
//         $group: {
//           _id: "$orderItems.product",
//           totalSold: { $sum: "$orderItems.quantity" },
//         },
//       },
//       { $sort: { totalSold: -1 } },
//       { $limit: 5 },
//     ]).lookup({
//       from: "products",
//       localField: "_id",
//       foreignField: "_id",
//       as: "product",
//     });

//     res.json({
//       totalRevenue: totalRevenue[0]?.total || 0,
//       completedOrders,
//       totalProductsSold: totalProductsSold[0]?.totalSold || 0,
//       canceledOrders,
//       topCustomers,
//       bestSellingProducts,
//     });
//   } catch (error) {
//     res.status(500).json({ message: "Lỗi server", error });
//   }
// };

// module.exports = { getSalesReport };


// const Order = require("../models/Order");
// const Product = require("../models/Product");
// const User = require("../models/User");

// // Báo cáo tổng hợp
// const getSalesReport = async (req, res) => {
//   try {
//     const totalRevenue = await Order.aggregate([
//       { $match: { status: "Hoàn thành" } },
//       { $group: { _id: null, total: { $sum: "$totalPrice" } } },
//     ]);

//     const completedOrders = await Order.countDocuments({ status: "Hoàn thành" });

//     const totalProductsSold = await Order.aggregate([
//       { $match: { status: "Hoàn thành" } },
//       { $unwind: "$orderItems" },
//       { $group: { _id: null, totalSold: { $sum: "$orderItems.quantity" } } },
//     ]);

//     const canceledOrders = await Order.countDocuments({ status: "Đã hủy" });

//     const topCustomers = await Order.aggregate([
//       { $match: { status: "Hoàn thành" } },
//       { $group: { _id: "$user", totalSpent: { $sum: "$totalPrice" } } },
//       { $sort: { totalSpent: -1 } },
//       { $limit: 5 },
//     ]).lookup({
//       from: "users",
//       localField: "_id",
//       foreignField: "_id",
//       as: "user",
//     });

//     const bestSellingProducts = await Order.aggregate([
//       { $match: { status: "Hoàn thành" } },
//       { $unwind: "$orderItems" },
//       {
//         $group: {
//           _id: "$orderItems.product",
//           totalSold: { $sum: "$orderItems.quantity" },
//         },
//       },
//       { $sort: { totalSold: -1 } },
//       { $limit: 5 },
//     ]).lookup({
//       from: "products",
//       localField: "_id",
//       foreignField: "_id",
//       as: "product",
//     });

//     res.json({
//       totalRevenue: totalRevenue[0]?.total || 0,
//       completedOrders,
//       totalProductsSold: totalProductsSold[0]?.totalSold || 0,
//       canceledOrders,
//       topCustomers,
//       bestSellingProducts,
//     });
//   } catch (error) {
//     res.status(500).json({ message: "Lỗi server", error });
//   }
// };

// // ✅ Thêm mới: Thống kê tổng số lượng user, sản phẩm và đơn hàng trong tháng hiện tại
// const getAdminStats = async (req, res) => {
//   try {
//     const totalUsers = await User.countDocuments();
//     const totalProducts = await Product.countDocuments();

//     // Lọc đơn hàng trong tháng hiện tại
//     const startOfMonth = new Date();
//     startOfMonth.setDate(1);
//     startOfMonth.setHours(0, 0, 0, 0);

//     const endOfMonth = new Date(startOfMonth);
//     endOfMonth.setMonth(endOfMonth.getMonth() + 1);

//     const monthlyOrders = await Order.countDocuments({
//       createdAt: { $gte: startOfMonth, $lt: endOfMonth }
//     });

//     res.json({
//       totalUsers,
//       totalProducts,
//       monthlyOrders
//     });
//   } catch (error) {
//     res.status(500).json({ message: "Lỗi server", error });
//   }
// };

// module.exports = {
//   getSalesReport,
//   getAdminStats
// };


const Order = require("../models/Order");
const Product = require("../models/Product");
const User = require("../models/User");

// Lấy báo cáo thống kê chi tiết
const getSalesReport = async (req, res) => {
  try {
    // 1. Tổng doanh thu từ đơn hàng hoàn thành
    const totalRevenue = await Order.aggregate([
      { $match: { status: "Hoàn thành" } },
      { $group: { _id: null, total: { $sum: "$totalPrice" } } }
    ]);

    // 2. Số đơn hàng đã hoàn thành
    const completedOrders = await Order.countDocuments({ status: "Hoàn thành" });

    // 3. Số lượng sản phẩm đã bán
    const totalProductsSold = await Order.aggregate([
      { $match: { status: "Hoàn thành" } },
      { $unwind: "$orderItems" },
      { $group: { _id: null, totalSold: { $sum: "$orderItems.quantity" } } }
    ]);

    // 4. Số đơn hàng bị hủy
    const canceledOrders = await Order.countDocuments({ status: "Đã hủy" });

    // 5. Top 5 khách hàng chi tiêu cao nhất
    const topCustomers = await Order.aggregate([
      { $match: { status: "Hoàn thành" } },
      { $group: { _id: "$user", totalSpent: { $sum: "$totalPrice" } } },
      { $sort: { totalSpent: -1 } },
      { $limit: 5 },
      {
        $lookup: {
          from: "users",
          localField: "_id",
          foreignField: "_id",
          as: "user"
        }
      },
      { $unwind: "$user" }
    ]);

    // 6. Top 5 sản phẩm bán chạy
    const bestSellingProducts = await Order.aggregate([
      { $match: { status: "Hoàn thành" } },
      { $unwind: "$orderItems" },
      {
        $group: {
          _id: "$orderItems.product",
          totalSold: { $sum: "$orderItems.quantity" }
        }
      },
      { $sort: { totalSold: -1 } },
      { $limit: 5 },
      {
        $lookup: {
          from: "products",
          localField: "_id",
          foreignField: "_id",
          as: "product"
        }
      },
      { $unwind: "$product" }
    ]);

    res.json({
      totalRevenue: totalRevenue[0]?.total || 0,
      completedOrders,
      totalProductsSold: totalProductsSold[0]?.totalSold || 0,
      canceledOrders,
      topCustomers,
      bestSellingProducts
    });
  } catch (error) {
    res.status(500).json({ message: "Lỗi server", error });
  }
};

// Route cho dashboard admin
const getAdminStats = async (req, res) => {
  try {
    const [userCount, productCount] = await Promise.all([
      User.countDocuments(),
      Product.countDocuments()
    ]);

    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);

    const orderCount = await Order.countDocuments({
      createdAt: { $gte: firstDay, $lte: lastDay }
    });

    res.json({ userCount, productCount, orderCount });
  } catch (err) {
    res.status(500).json({ message: "Lỗi server khi lấy thống kê" });
  }
};

module.exports = {
  getSalesReport,
  getAdminStats
};
