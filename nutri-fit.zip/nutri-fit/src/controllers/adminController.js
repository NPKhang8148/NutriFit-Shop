const User = require("../models/User");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

// Đăng nhập Admin
exports.adminLogin = async (req, res) => {
    const { email, password } = req.body;

    try {
        const admin = await User.findOne({ email, role: "admin" });

        if (!admin) {
            return res.status(400).json({ message: "Admin không tồn tại hoặc sai thông tin đăng nhập!" });
        }

        if (admin.isBanned) {
            return res.status(403).json({ message: "Tài khoản của bạn đã bị khóa!" });
        }

        const isMatch = await bcrypt.compare(password, admin.password);
        if (!isMatch) {
            return res.status(400).json({ message: "Email hoặc mật khẩu không đúng!" });
        }

        const token = jwt.sign({ _id: admin._id, role: admin.role }, process.env.JWT_SECRET, { expiresIn: "7d" });

        res.json({ token, admin });
    } catch (error) {
        res.status(500).json({ message: "Lỗi máy chủ", error });
    }
};

// Lấy danh sách tất cả user (chỉ dành cho admin)
exports.getAllUsers = async (req, res) => {
    try {
        const users = await User.find({ isAdmin: false }).select("-password"); // Không trả về password
        res.json(users);
    } catch (error) {
        res.status(500).json({ message: "Lỗi máy chủ", error });
    }
};

// Khóa/Mở khóa tài khoản user
exports.toggleBanUser = async (req, res) => {
    const { userId } = req.params;

    try {
        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({ message: "Không tìm thấy người dùng!" });
        }

        // Đảo trạng thái khóa/mở khóa
        user.isBanned = !user.isBanned;
        await user.save();

        res.json({ message: `Tài khoản đã được ${user.isBanned ? "khóa" : "mở khóa"} thành công!`, user });
    } catch (error) {
        res.status(500).json({ message: "Lỗi máy chủ", error });
    }
};
