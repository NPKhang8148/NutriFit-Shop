// const axios = require('axios');

// // Xử lý POST /api/chat
// const chatWithLMStudio = async (req, res) => {
//   const { message } = req.body;

//   if (!message) {
//     return res.status(400).json({ error: 'Vui lòng cung cấp message' });
//   }

//   try {
//     const response = await axios.post(`${process.env.LM_API_BASE_URL}/chat/completions`, {
//       messages: [
//         { role: "system", content: "Bạn là một trợ lý ảo chuyên tư vấn tập luyện và dinh dưỡng." },
//         { role: "user", content: message }
//       ],
//       model: "llama3", // Đổi thành model bạn đang sử dụng trong LM Studio
//       temperature: 0.7
//     });

//     const reply = response.data.choices[0].message.content;
//     res.json({ reply });
//   } catch (error) {
//     console.error("Lỗi khi gọi LM Studio:", error?.response?.data || error.message);
//     res.status(500).json({ error: 'Lỗi khi kết nối đến LM Studio API' });
//   }
// };

// module.exports = { chatWithLMStudio };

// src/controllers/chatController.js

// // src/controllers/chatController.js
// const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));
// require('dotenv').config();

// const chatWithLMStudio = async (req, res) => {
//   try {
//     const userMessage = req.body.message;

//     if (!userMessage || typeof userMessage !== 'string') {
//       return res.status(400).json({ error: 'Message is required and must be a string.' });
//     }

//     const response = await fetch(`${process.env.LM_API_BASE_URL}/completions`, {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json',
//       },
//       body: JSON.stringify({
//         model: 'llama3', // hoặc tên model đang chạy trong LM Studio
//         prompt: userMessage,
//         max_tokens: 512,
//         temperature: 0.7,
//         stream: false,
//       }),
//     });

//     const data = await response.json();

//     if (data.error) {
//       console.error('LM Studio error:', data);
//       return res.status(500).json({ error: data.error });
//     }

//     res.json({ reply: data.choices[0]?.text.trim() || '(Không có phản hồi)' });
//   } catch (error) {
//     console.error('Chat error:', error.message);
//     res.status(500).json({ error: 'Lỗi máy chủ khi gọi LM Studio' });
//   }
// };

// module.exports = { chatWithLMStudio };

const fetch = (...args) =>
  import("node-fetch").then(({ default: fetch }) => fetch(...args));
require("dotenv").config();

const chatWithLMStudio = async (req, res) => {
  try {
    const userMessage = req.body.message;

    const systemPrompt = `
Bạn là một huấn luyện viên AI cho website bán dụng cụ tập luyện và thực phẩm bổ sung. 
Bạn cần tư vấn tập luyện, chế độ ăn uống, sản phẩm bổ sung, và tính BMI/calories.
Luôn hỏi lại nếu chưa đủ thông tin.
`;

    const fullPrompt = `${systemPrompt}\n\nNgười dùng: ${userMessage}`;

    const response = await fetch(`${process.env.LM_API_BASE_URL}/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "Meta-Llama-3-8B-Instruct.Q4_K_M.gguf",
        prompt: fullPrompt,
        max_tokens: 500,
        temperature: 0.7,
        stream: false,
      }),
    });

    const data = await response.json();

    if (data.error) {
      console.error("LM Studio error:", data);
      return res.status(500).json({ error: data.error });
    }

    res.json({ reply: data.choices[0]?.text.trim() || "(Không có phản hồi)" });
  } catch (error) {
    console.error("Chat error:", error.message);
    res.status(500).json({ error: "Lỗi máy chủ khi gọi LM Studio" });
  }
};

module.exports = { chatWithLMStudio };
