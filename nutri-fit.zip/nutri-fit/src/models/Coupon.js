const mongoose = require("mongoose");

const couponSchema = new mongoose.Schema(
  {
    code: { type: String, required: true, unique: true },
    discount: { type: Number, required: true }, // Giá trị giảm giá
    discountType: {
      type: String,
      enum: ["percentage", "fixed"],
      default: "percentage",
    }, // Phần trăm (%) hoặc số tiền cố định (VNĐ)
    expiryDate: { type: Date, required: true }, // Ngày hết hạn
    quantity: { type: Number, required: true }, // Số lượng mã giảm giá còn lại
    usedCount: { type: Number, default: 0 }, // Số lần đã sử dụng
  },
  { timestamps: true }
);

// Thêm phương thức kiểm tra mã hợp lệ
couponSchema.methods.isValid = function () {
  return this.quantity > this.usedCount && this.expiryDate > new Date();
};

const Coupon = mongoose.model("Coupon", couponSchema);
module.exports = Coupon;
