const mongoose = require('mongoose');

const reviewSchema = new mongoose.Schema(
    {
      user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
      rating: { type: Number, required: true, min: 1, max: 5 },
      comment: { type: String, required: true },
    },
    { timestamps: true }
  );

const productSchema = new mongoose.Schema({
    name: { type: String, required: true },
    price: { type: Number, required: true },
    description: { type: String },
    image: { type: String }, // URL ảnh sản phẩm
    category: { type: mongoose.Schema.Types.ObjectId, ref: 'Category', required: true }, // Liên kết danh mục
    stock: { type: Number, required: true, default: 0 },
    reviews: [reviewSchema], // Thêm danh sách đánh giá
    averageRating: { type: Number, default: 0 }, // Trung bình sao
}, { timestamps: true });

const Product = mongoose.model('Product', productSchema);
module.exports = Product;
