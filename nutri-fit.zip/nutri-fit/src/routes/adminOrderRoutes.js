const express = require("express");
const Order = require("../models/Order");
const Product = require("../models/Product");
const { auth, adminAuth } = require("../middlewares/authMiddleware");

const router = express.Router();

// Xem tất cả đơn hàng
router.get("/", auth, adminAuth, async (req, res) => {
    try {
        const orders = await Order.find()
            .populate("user", "name email")
            .populate("orderItems.product", "name");
        res.json(orders);
    } catch (error) {
        res.status(500).json({ message: "Lỗi server", error });
    }
});

// Xem chi tiết đơn hàng
router.get("/:id", auth, adminAuth, async (req, res) => {
    try {
        const order = await Order.findById(req.params.id)
            .populate("user", "name email")
            .populate("orderItems.product", "name");

        if (!order) {
            return res.status(404).json({ message: "Không tìm thấy đơn hàng" });
        }

        res.json(order);
    } catch (error) {
        res.status(500).json({ message: "Lỗi server", error });
    }
});

// Xác nhận đơn hàng
router.put("/:id/confirm", auth, adminAuth, async (req, res) => {
    try {
        const order = await Order.findById(req.params.id);

        if (!order) return res.status(404).json({ message: "Không tìm thấy đơn hàng" });

        if (order.status !== "Chờ xác nhận") {
            return res.status(400).json({ message: "Đơn hàng đã được xử lý trước đó" });
        }

        order.status = "Đã xác nhận";
        await order.save();

        const updated = await Order.findById(order._id)
            .populate("user", "name email")
            .populate("orderItems.product", "name");

        res.json({ message: "Xác nhận đơn hàng thành công", order: updated });
    } catch (error) {
        res.status(500).json({ message: "Lỗi server", error });
    }
});

// Hủy đơn hàng + hoàn kho
router.put("/:id/cancel", auth, adminAuth, async (req, res) => {
    try {
        const order = await Order.findById(req.params.id);

        if (!order) return res.status(404).json({ message: "Không tìm thấy đơn hàng" });

        if (order.status !== "Chờ xác nhận") {
            return res.status(400).json({ message: "Chỉ có thể hủy đơn hàng khi đang chờ xác nhận" });
        }

        for (const item of order.orderItems) {
            const product = await Product.findById(item.product);
            if (product) {
                product.stock += item.quantity;
                await product.save();
            }
        }

        order.status = "Đã hủy";
        await order.save();

        const updated = await Order.findById(order._id)
            .populate("user", "name email")
            .populate("orderItems.product", "name");

        res.json({ message: "Đơn hàng đã bị hủy và hoàn kho", order: updated });
    } catch (error) {
        res.status(500).json({ message: "Lỗi server", error });
    }
});

// Admin đánh dấu đơn hàng đã giao
// PUT /api/admin/orders/:id/deliver
router.put("/:id/deliver", auth, adminAuth, async (req, res) => {
    try {
      const order = await Order.findById(req.params.id)
  
      if (!order) {
        return res.status(404).json({ message: "Không tìm thấy đơn hàng" })
      }
  
      if (order.status !== "Đã xác nhận") {
        return res.status(400).json({ message: "Chỉ có thể giao hàng khi đơn đã được xác nhận" })
      }
  
      order.status = "Đã giao hàng"
      await order.save()
  
      res.json({ message: "Đơn hàng đã được đánh dấu là đã giao", order })
    } catch (error) {
      console.error("❌ Lỗi khi xử lý giao hàng:", error)
      res.status(500).json({ message: "Lỗi server khi cập nhật trạng thái giao hàng", error: error.message })
    }
  })
  


// Xóa đơn hàng
router.delete("/:id", auth, adminAuth, async (req, res) => {
    try {
        const order = await Order.findById(req.params.id);
        if (!order) {
            return res.status(404).json({ message: "Không tìm thấy đơn hàng" });
        }

        await order.deleteOne();
        res.json({ message: "Xóa đơn hàng thành công" });
    } catch (error) {
        res.status(500).json({ message: "Lỗi server", error });
    }
});

module.exports = router;
