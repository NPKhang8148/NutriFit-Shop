// const express = require("express");
// const Order = require("../models/Order");
// const Product = require("../models/Product");
// const { auth } = require("../middlewares/authMiddleware");
// const {
//   createOrder,
//   cancelOrder,
//   getUserOrders,
//   getAllOrders,
//   updateOrderStatus,
// } = require("../controllers/orderController");

// const router = express.Router();

// // User đặt đơn hàng
// // Sử dụng controller
// router.post("/", auth, createOrder);

// // User xem chi tiết đơn hàng của chính mình
// router.get("/:id", auth, async (req, res) => {
//   try {
//     const order = await Order.findById(req.params.id);

//     if (!order) {
//       return res.status(404).json({ message: "Không tìm thấy đơn hàng" });
//     }

//     if (order.user.toString() !== req.user._id.toString()) {
//       return res
//         .status(403)
//         .json({ message: "Bạn không có quyền xem đơn hàng này" });
//     }

//     res.json(order);
//   } catch (error) {
//     res.status(500).json({ message: "Lỗi server", error });
//   }
// });

// // User xem danh sách đơn hàng của chính mình
// router.get("/", auth, async (req, res) => {
//   try {
//     const orders = await Order.find({ user: req.user._id }).sort({
//       createdAt: -1,
//     });
//     res.json(orders);
//   } catch (error) {
//     res.status(500).json({ message: "Lỗi server", error });
//   }
// });

// // User hủy đơn hàng (chỉ khi đang chờ xác nhận)
// router.put("/:id/cancel", auth, async (req, res) => {
//   try {
//     const order = await Order.findById(req.params.id);

//     if (!order) {
//       return res.status(404).json({ message: "Không tìm thấy đơn hàng" });
//     }

//     if (order.user.toString() !== req.user._id.toString()) {
//       return res
//         .status(403)
//         .json({ message: "Bạn không có quyền hủy đơn hàng này" });
//     }

//     if (order.status !== "Chờ xác nhận") {
//       return res
//         .status(400)
//         .json({ message: "Chỉ có thể hủy đơn hàng khi đang chờ xác nhận" });
//     }

//     // Hoàn lại số lượng kho
//     for (const item of order.orderItems) {
//       const product = await Product.findById(item.product);
//       if (product) {
//         product.stock += item.quantity;
//         await product.save();
//       }
//     }

//     order.status = "Đã hủy";
//     await order.save();

//     res.json({ message: "Hủy đơn hàng thành công!", order });
//   } catch (error) {
//     res.status(500).json({ message: "Lỗi server", error });
//   }
// });

// module.exports = router;

const express = require("express");
const Order = require("../models/Order");
const Product = require("../models/Product");
const { auth } = require("../middlewares/authMiddleware");
const {
  createOrder,
  cancelOrder,
  getUserOrders,
  getAllOrders,
  updateOrderStatus,
} = require("../controllers/orderController");

const router = express.Router();

//  User đặt đơn hàng
// Sử dụng controller
router.post("/", auth, createOrder);

// xem đh
router.get("/:id", auth, async (req, res) => {
  try {
    const order = await Order.findById(req.params.id).populate({
      path: "orderItems.product",
      select: "name price options", // <-- thêm "options" ở đây
    });

    if (!order) {
      return res.status(404).json({ message: "Không tìm thấy đơn hàng" });
    }

    if (order.user.toString() !== req.user._id.toString()) {
      return res
        .status(403)
        .json({ message: "Bạn không có quyền xem đơn hàng này" });
    }

    res.json(order);
  } catch (error) {
    res.status(500).json({ message: "Lỗi server", error });
  }
});

// User xem danh sách đơn hàng của chính mình
router.get("/", auth, async (req, res) => {
  try {
    const orders = await Order.find({ user: req.user._id }).sort({
      createdAt: -1,
    });
    res.json(orders);
  } catch (error) {
    res.status(500).json({ message: "Lỗi server", error });
  }
});

//User hủy đơn hàng (đang chờ xác nhận)
router.put("/:id/cancel", auth, async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);

    if (!order) {
      return res.status(404).json({ message: "Không tìm thấy đơn hàng" });
    }

    if (order.user.toString() !== req.user._id.toString()) {
      return res
        .status(403)
        .json({ message: "Bạn không có quyền hủy đơn hàng này" });
    }

    if (order.status !== "Chờ xác nhận") {
      return res
        .status(400)
        .json({ message: "Chỉ có thể hủy đơn hàng khi đang chờ xác nhận" });
    }

    // Hoàn lại số lượng kho
    for (const item of order.orderItems) {
      const product = await Product.findById(item.product);
      if (product) {
        product.stock += item.quantity;
        await product.save();
      }
    }

    order.status = "Đã hủy";
    await order.save();

    res.json({ message: "Hủy đơn hàng thành công!", order });
  } catch (error) {
    res.status(500).json({ message: "Lỗi server", error });
  }
});

// POST /api/orders/:id/complete
router.post("/:id/complete", auth, async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order)
      return res.status(404).json({ message: "Không tìm thấy đơn hàng" });

    // Chỉ chủ đơn hàng mới được xác nhận
    if (order.user.toString() !== req.user._id.toString()) {
      return res
        .status(403)
        .json({ message: "Không có quyền xác nhận đơn hàng này" });
    }

    if (order.status !== "Đã giao hàng") {
      return res.status(400).json({ message: "Đơn hàng chưa được giao" });
    }

    order.status = "Hoàn thành";
    await order.save();

    res.json({ message: "Đơn hàng đã được hoàn thành!" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Lỗi server" });
  }
});

// Cập nhật số lượng sản phẩm trong đơn hàng (chỉ khi đang chờ xác nhận)
router.put("/:id/update-quantity", auth, async (req, res) => {
  try {
    const { productId, newQuantity } = req.body;

    if (!productId || newQuantity <= 0) {
      return res.status(400).json({ message: "Dữ liệu không hợp lệ" });
    }

    const order = await Order.findById(req.params.id).populate(
      "orderItems.product"
    );
    if (!order) {
      return res.status(404).json({ message: "Không tìm thấy đơn hàng" });
    }

    if (order.user.toString() !== req.user._id.toString()) {
      return res
        .status(403)
        .json({ message: "Không có quyền sửa đơn hàng này" });
    }

    if (order.status !== "Chờ xác nhận") {
      return res
        .status(400)
        .json({ message: "Chỉ có thể sửa khi đơn hàng đang chờ xác nhận" });
    }

    const item = order.orderItems.find(
      (i) => i.product._id.toString() === productId
    );
    if (!item) {
      return res
        .status(404)
        .json({ message: "Sản phẩm không tồn tại trong đơn hàng" });
    }

    // Kiểm tra tồn kho
    const product = await Product.findById(productId);
    if (!product || product.stock + item.quantity < newQuantity) {
      return res.status(400).json({ message: "Không đủ hàng trong kho" });
    }

    // Cập nhật tồn kho
    product.stock += item.quantity; // Hoàn lại số cũ
    product.stock -= newQuantity; // Trừ số mới
    await product.save();

    // Cập nhật số lượng & tổng giá
    item.quantity = newQuantity;
    order.totalPrice = order.orderItems.reduce(
      (sum, i) => sum + i.product.price * i.quantity,
      0
    );

    await order.save();

    res.json({ message: "Cập nhật số lượng thành công", order });
  } catch (error) {
    res.status(500).json({ message: "Lỗi server", error });
  }
});

// Áp dụng mã giảm giá
router.post("/apply-coupon", auth, async (req, res) => {
  try {
    const { couponCode, totalPrice } = req.body;

    if (!couponCode) {
      return res.status(400).json({ message: "Vui lòng nhập mã giảm giá" });
    }

    const coupon = await Coupon.findOne({ code: couponCode });
    if (!coupon) {
      return res.status(400).json({ message: "Mã giảm giá không hợp lệ" });
    }

    if (new Date(coupon.expiryDate) < new Date()) {
      return res.status(400).json({ message: "Mã giảm giá đã hết hạn" });
    }

    if (totalPrice < coupon.minOrderValue) {
      return res.status(400).json({
        message: `Đơn hàng phải từ ${coupon.minOrderValue} để áp dụng mã`,
      });
    }

    const discountAmount = (totalPrice * coupon.discount) / 100;
    const newTotalPrice = totalPrice - discountAmount;

    res.json({
      message: "Áp dụng mã giảm giá thành công",
      discountAmount,
      newTotalPrice,
    });
  } catch (error) {
    res.status(500).json({ message: "Lỗi server", error });
  }
});

module.exports = router;
