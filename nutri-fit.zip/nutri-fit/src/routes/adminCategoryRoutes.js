const express = require('express');
const Category = require('../models/Category');
const { auth, adminAuth } = require('../middlewares/authMiddleware');

const router = express.Router();

// Thêm danh mục mới
router.post('/', auth, adminAuth, async (req, res) => {
    const { name } = req.body;
    try {
        const categoryExists = await Category.findOne({ name });
        if (categoryExists) {
            return res.status(400).json({ message: 'Danh mục đã tồn tại' });
        }

        const category = await Category.create({ name });
        res.status(201).json(category);
    } catch (error) {
        res.status(500).json({ message: 'Lỗi server', error });
    }
});

// Lấy danh sách danh mục
router.get('/', auth, adminAuth, async (req, res) => {
    try {
        const categories = await Category.find();
        res.json(categories);
    } catch (error) {
        console.error("Lỗi lấy danh sách danh mục:", error.message);
        res.status(500).json({ message: 'Lỗi server', error: error.message });
    }
});


// Cập nhật danh mục
router.put('/:id', auth, adminAuth, async (req, res) => {
    try {
        const category = await Category.findById(req.params.id);
        if (!category) {
            return res.status(404).json({ message: 'Danh mục không tồn tại' });
        }

        category.name = req.body.name || category.name;
        await category.save();

        res.json({ message: 'Cập nhật thành công', category });
    } catch (error) {
        res.status(500).json({ message: 'Lỗi server', error });
    }
});

// Xóa danh mục
router.delete('/:id', auth, adminAuth, async (req, res) => {
    try {
        const category = await Category.findById(req.params.id);
        if (!category) {
            return res.status(404).json({ message: 'Danh mục không tồn tại' });
        }

        await category.deleteOne();
        res.json({ message: 'Xóa thành công' });
    } catch (error) {
        res.status(500).json({ message: 'Lỗi server', error });
    }
});

// Route public: Lấy tất cả danh mục
router.get('/', async (req, res) => {
  try {
    const categories = await Category.find();
    res.json(categories);
  } catch (error) {
    console.error('Lỗi lấy danh mục public:', error);
    res.status(500).json({ message: 'Lỗi server', error });
  }
});

module.exports = router;