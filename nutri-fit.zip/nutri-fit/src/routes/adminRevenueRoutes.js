const express = require("express");
const router = express.Router();
const { adminAuth } = require("../middlewares/authMiddleware");
const { getRevenueStats } = require("../controllers/revenueController");

// API thống kê doanh thu (chỉ admin)
router.get("/", adminAuth, getRevenueStats);

module.exports = router;
