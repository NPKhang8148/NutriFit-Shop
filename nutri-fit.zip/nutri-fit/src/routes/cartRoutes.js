// routes/cartRoutes.js
const express = require("express");
const router = express.Router();
const Cart = require("../models/Cart");

// Lấy giỏ hàng
router.get("/:userId", async (req, res) => {
  const cart = await Cart.findOne({ userId: req.params.userId }).populate(
    "items.productId"
  );
  res.json(cart);
});

// Xóa sản phẩm
router.post("/remove", async (req, res) => {
  const { userId, productId } = req.body;
  const cart = await Cart.findOne({ userId });

  if (cart) {
    cart.items = cart.items.filter(
      (item) => item.productId.toString() !== productId
    );
    await cart.save();
  }

  res.json(cart);
});

// Thêm sản phẩm vào giỏ
router.post("/add", async (req, res) => {
  const { userId, productId, quantity } = req.body;

  if (!userId || !productId || !quantity) {
    return res
      .status(400)
      .json({ message: "Thiếu userId, productId hoặc quantity" });
  }

  try {
    let cart = await Cart.findOne({ userId });

    if (!cart) {
      cart = new Cart({ userId, items: [] });
    }

    const itemIndex = cart.items.findIndex(
      (item) => item.productId.toString() === productId
    );
    if (itemIndex > -1) {
      cart.items[itemIndex].quantity += quantity;
    } else {
      cart.items.push({ productId, quantity });
    }

    await cart.save();
    res.json(cart);
  } catch (error) {
    console.error("Lỗi khi thêm giỏ hàng:", error);
    res.status(500).json({ message: "Lỗi server khi thêm vào giỏ hàng" });
  }
});


// API cập nhật số lượng sản phẩm trong giỏ hàng
router.post("/update", async (req, res) => {
  try {
    const { userId, productId, quantity } = req.body;

    if (!userId || !productId || quantity == null) {
      return res.status(400).json({ message: "Thiếu dữ liệu" });
    }

    // Không cho số lượng < 1
    if (quantity < 1) {
      return res.status(400).json({ message: "Số lượng phải >= 1" });
    }

    const cart = await Cart.findOne({ userId }).populate("items.productId");

    if (!cart) {
      return res.status(404).json({ message: "Không tìm thấy giỏ hàng" });
    }

    const itemIndex = cart.items.findIndex(
      (item) => item.productId._id.toString() === productId
    );

    if (itemIndex === -1) {
      return res.status(404).json({ message: "Sản phẩm không có trong giỏ hàng" });
    }

    cart.items[itemIndex].quantity = quantity;
    await cart.save();

    res.json({ message: "Cập nhật số lượng thành công", cart });
  } catch (error) {
    console.error("Lỗi update số lượng:", error);
    res.status(500).json({ message: "Lỗi server", error: error.message });
  }
});


module.exports = router;
