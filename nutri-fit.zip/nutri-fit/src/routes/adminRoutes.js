const express = require('express');
const Admin = require('../models/Admin');
const jwt = require('jsonwebtoken');
const bcrypt = require("bcryptjs");
const { auth, adminAuth } = require("../middlewares/authMiddleware");
const { getSalesReport } = require("../controllers/statsController"); 
const Product = require("../models/Product");
const User = require("../models/User");

const router = express.Router();

// Hàm tạo token
const generateToken = (id) => {
    return jwt.sign({ id, role: "admin" }, process.env.JWT_SECRET, { expiresIn: '30d' });
};

// Đăng ký admin
router.post('/register', async (req, res) => {
    const { name, email, password } = req.body;

    const adminExists = await Admin.findOne({ email });
    if (adminExists) {
        return res.status(400).json({ message: 'Email đã được sử dụng' });
    }

    const admin = await Admin.create({
        name,
        email,
        password,
        role: "admin",
    });

    if (admin) {
        res.status(201).json({
            _id: admin._id,
            name: admin.name,
            email: admin.email,
            role: admin.role,
            token: generateToken(admin._id),
        });
    } else {
        res.status(400).json({ message: 'Không thể đăng ký' });
    }
});

// Đăng nhập admin
router.post('/login', async (req, res) => {
    const { email, password } = req.body;

    const admin = await Admin.findOne({ email });

    if (admin && (await admin.matchPassword(password))) {
        res.json({
            _id: admin._id,
            name: admin.name,
            email: admin.email,
            role: admin.role,
            token: generateToken(admin._id),
        });
    } else {
        res.status(401).json({ message: 'Sai email hoặc mật khẩu' });
    }
});

// Lấy danh sách tất cả người dùng (chỉ admin)
router.get("/users", auth, adminAuth, async (req, res) => {
    try {
        const users = await User.find().select("-password"); // Loại bỏ trường password khi trả về
        res.json(users);
    } catch (error) {
        res.status(500).json({ message: "Lỗi khi lấy danh sách người dùng" });
    }
});

router.put("/products/:id/stock", auth, adminAuth, async (req, res) => {
    try {
        const { stock } = req.body;
        const product = await Product.findById(req.params.id);

        if (!product) {
            return res.status(404).json({ message: "Sản phẩm không tồn tại" });
        }

        product.stock = stock;
        await product.save();

        res.json({ message: "Cập nhật số lượng kho thành công!", product });
    } catch (error) {
        res.status(500).json({ message: "Lỗi server", error });
    }
});

// 📊 API Thống kê và báo cáo
router.get("/stats", auth, adminAuth, getSalesReport);

module.exports = router;
