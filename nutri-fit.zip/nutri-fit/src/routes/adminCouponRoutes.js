const express = require("express");
const Coupon = require("../models/Coupon");
const { auth, adminAuth } = require("../middlewares/authMiddleware");

const router = express.Router();

// Admin tạo mã giảm giá
router.post("/", auth, adminAuth, async (req, res) => {
  try {
    const { code, discount, quantity, expiryDate } = req.body;
    const exists = await Coupon.findOne({ code });
    if (exists) return res.status(400).json({ message: "Mã này đã tồn tại!" });

    const coupon = await Coupon.create({
      code,
      discount,
      quantity,
      expiryDate,
    });
    res.status(201).json(coupon);
  } catch (error) {
    res.status(500).json({ message: "Lỗi server", error });
  }
});

// Admin lấy danh sách mã giảm giá
router.get("/", auth, adminAuth, async (req, res) => {
  try {
    const coupons = await Coupon.find();
    res.json(coupons);
  } catch (error) {
    res.status(500).json({ message: "Lỗi server", error });
  }
});

// Admin cập nhật mã giảm giá
router.put("/:id", auth, adminAuth, async (req, res) => {
  try {
    const coupon = await Coupon.findById(req.params.id);
    if (!coupon)
      return res.status(404).json({ message: "Không tìm thấy mã giảm giá" });

    Object.assign(coupon, req.body);
    await coupon.save();
    res.json({ message: "Cập nhật mã giảm giá thành công!", coupon });
  } catch (error) {
    res.status(500).json({ message: "Lỗi server", error });
  }
});

// Admin xóa mã giảm giá
router.delete("/:id", auth, adminAuth, async (req, res) => {
  try {
    const coupon = await Coupon.findById(req.params.id);
    if (!coupon)
      return res.status(404).json({ message: "Không tìm thấy mã giảm giá" });

    await coupon.deleteOne();
    res.json({ message: "Xóa mã giảm giá thành công!" });
  } catch (error) {
    res.status(500).json({ message: "Lỗi server", error });
  }
});



// API áp dụng mã giảm giá
router.post("/apply", async (req, res) => {
  try {
    const { code, total } = req.body;

    if (!code || total == null) {
      return res.status(400).json({ message: "Thiếu dữ liệu" });
    }

    const coupon = await Coupon.findOne({ code: code.trim().toUpperCase() });

    if (!coupon) {
      return res.status(404).json({ message: "Mã giảm giá không tồn tại" });
    }

    // Kiểm tra ngày hết hạn
    const now = new Date();
    if (coupon.expiryDate && coupon.expiryDate < now) {
      return res.status(400).json({ message: "Mã giảm giá đã hết hạn" });
    }

    // Kiểm tra tổng tối thiểu
    if (coupon.minOrder && total < coupon.minOrder) {
      return res.status(400).json({
        message: `Đơn hàng tối thiểu ${coupon.minOrder.toLocaleString()} đ để áp dụng mã này`,
      });
    }

    // Tính giá trị giảm
    let discountAmount = 0;
    if (coupon.type === "percent") {
      discountAmount = Math.floor((total * coupon.value) / 100);
    } else {
      discountAmount = coupon.value;
    }

    // Không vượt quá total
    if (discountAmount > total) {
      discountAmount = total;
    }

    res.json({ discountAmount });
  } catch (error) {
    console.error("Lỗi áp mã giảm giá:", error);
    res.status(500).json({ message: "Lỗi server", error: error.message });
  }
});


module.exports = router;
