const express = require("express");
const Category = require("../models/Category");

const router = express.Router();

// Route public: Lấy danh sách danh mục (không cần token)
router.get("/", async (req, res) => {
  try {
    const categories = await Category.find();
    res.json(categories);
  } catch (error) {
    console.error("Lỗi lấy danh mục public:", error.message);
    res.status(500).json({ message: "Lỗi server", error: error.message });
  }
});

module.exports = router;
