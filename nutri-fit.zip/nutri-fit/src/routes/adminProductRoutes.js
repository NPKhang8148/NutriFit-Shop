const express = require('express');
const Product = require('../models/Product');
const Category = require('../models/Category');
const { auth, adminAuth } = require('../middlewares/authMiddleware');
const mongoose = require('mongoose');
const multer = require('multer');
const path = require('path');

const router = express.Router();

// Cấu hình nơi lưu ảnh
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/'); // Ảnh sẽ lưu trong thư mục uploads/
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname)); // Đặt tên file theo thời gian
    }
});

const upload = multer({ storage: storage });

// API tải ảnh lên
router.post('/upload', upload.single('image'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ message: 'Không có file nào được tải lên' });
    }

    const imageUrl = `/uploads/${req.file.filename}`; // Trả về đường dẫn ảnh
    res.json({ imageUrl });
});


// Lấy danh sách sản phẩm + tên danh mục
router.get('/products', auth, adminAuth, async (req, res) => {
    try {
        const products = await Product.find().populate('category', 'name');

        // Xử lý danh mục bị null
        const formattedProducts = products.map(p => ({
            ...p.toObject(),
            category: p.category ? p.category : { _id: null, name: "Không xác định" }
        }));

        res.json({ products: formattedProducts });
    } catch (error) {
        res.status(500).json({ message: "Lỗi server", error });
    }
});



// Thêm sản phẩm mới
router.post('/products', auth, adminAuth, async (req, res) => {
    let { name, price, description, image, category, stock } = req.body;

    try {
        // Kiểm tra xem category có hợp lệ không
        if (!mongoose.Types.ObjectId.isValid(category)) {
            return res.status(400).json({ message: "ID danh mục không hợp lệ" });
        }

        const categoryExists = await Category.findById(category);
        if (!categoryExists) {
            return res.status(404).json({ message: "Danh mục không tồn tại" });
        }

        const product = new Product({ name, price, description, image, category, stock });
        await product.save();

        // Populate category để trả về đầy đủ dữ liệu
        const populatedProduct = await product.populate('category', 'name');

        res.status(201).json({ message: "Sản phẩm đã được thêm", product: populatedProduct });
    } catch (error) {
        res.status(500).json({ message: "Lỗi server", error });
    }
});

// Cập nhật sản phẩm
router.put('/products/:id', auth, adminAuth, async (req, res) => {
    const { name, price, description, image, category, stock } = req.body;

    try {
        const product = await Product.findById(req.params.id);
        if (!product) {
            return res.status(404).json({ message: "Sản phẩm không tồn tại" });
        }

        // Nếu category không null, kiểm tra xem có hợp lệ không
        if (category && !mongoose.Types.ObjectId.isValid(category)) {
            return res.status(400).json({ message: "ID danh mục không hợp lệ" });
        }

        if (category) {
            const categoryExists = await Category.findById(category);
            if (!categoryExists) {
                return res.status(404).json({ message: "Danh mục không tồn tại" });
            }
        }

        // Cập nhật sản phẩm
        product.name = name || product.name;
        product.price = price || product.price;
        product.description = description || product.description;
        product.image = image || product.image;
        product.stock = stock || product.stock;

        // Chỉ cập nhật category nếu có giá trị hợp lệ
        if (category) {
            product.category = category;
        }

        await product.save();
        const updatedProduct = await product.populate('category', 'name');

        res.json({ message: "Cập nhật thành công", product: updatedProduct });
    } catch (error) {
        res.status(500).json({ message: "Lỗi server", error });
    }
});


// Xóa sản phẩm
router.delete('/products/:id', auth, adminAuth, async (req, res) => {
    try {
        const product = await Product.findById(req.params.id);
        if (!product) {
            return res.status(404).json({ message: "Sản phẩm không tồn tại" });
        }

        await product.deleteOne();
        res.json({ message: "Xóa sản phẩm thành công" });
    } catch (error) {
        res.status(500).json({ message: "Lỗi server", error });
    }
});

module.exports = router;
