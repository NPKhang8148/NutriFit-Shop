const express = require('express');
const router = express.Router();
const { chatWithLMStudio } = require('../controllers/chatController');

router.post('/chat', chatWithLMStudio);

module.exports = router;
